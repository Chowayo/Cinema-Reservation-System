import mysql.connector #For database import
from functools import partial

from PyQt6 import QtWidgets, uic
from database.DBConnection import create_db_connection

#SESSION/Global Variables
session_employeeID=""
session_fName=""
session_lName=""
session_email=""
session_password=""

#LOGIN SCREEN
class LoginScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/login.ui", self) 
        self.stacked_widget = stacked_widget
        
        self.registerBtn.clicked.connect(self.goto_register)
        self.loginBtn.clicked.connect(self.loginLogic)
        
        
    def goto_register(self):
        self.stacked_widget.setCurrentIndex(1)
        self.stacked_widget.setFixedSize(580, 630)
        
            
    #TO DASHBOARD
    def goto_dashboard(self):
        self.stacked_widget.setCurrentIndex(2)
        
        #Remove size limits
        self.stacked_widget.setMinimumSize(0, 0)
        self.stacked_widget.setMaximumSize(16777215, 16777215)
        
        # full screen
        self.stacked_widget.showMaximized() 
        
        dash_screen = self.stacked_widget.widget(2) 
        dash_screen.load_latest()
        
        
    def loginLogic(self ):
            #Login Logic starts here
            employeeId = str(self.employeeID.text()) 
            password = str(self.password.text())   
            mydb = create_db_connection()
            ready = mydb.cursor()
            ready.execute("SELECT employeeID, first_name, last_name, email, password FROM employees WHERE employeeID = %s AND password = %s",(employeeId, password))
            
            #Takes the result of SELECT
            result = ready.fetchall()
            
            #add decryptor here
            if(employeeId != "" and password != ""):
                if(result!=[]):
                    print("May nag match")
                    for i in result:
                        
                        #Pang change ng value ng mga global Variable
                        global session_employeeID
                        global session_fName
                        global session_lName
                        global session_email
                        global session_password
                                                              
                        session_employeeID = i[0]
                        session_fName = i[1]
                        session_lName = i[2]
                        session_email = i[3]
                        session_password = i[4]
                    self.goto_dashboard()
                    
                else:
                    print("Walang nag match")
            else:
                print("Empty Box Detected!")
           
           
                

#REGISTER SCREEN
class RegisterScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/register.ui", self)
        self.stacked_widget = stacked_widget
        
        #To login button
        self.signInBtn.clicked.connect(self.goto_login)
        
        #Register button
        self.signUpBtn.clicked.connect(self.registerLogic)      
        
    #For loading Register page
    def goto_login(self):
        self.stacked_widget.setCurrentIndex(0)
        self.stacked_widget.setFixedSize(455, 455)    

    def registerLogic(self):
        fname = str(self.firstName.text()) 
        lname = str(self.lastName.text()) 
        employeeId = str(self.employeeID.text()) 
        email = str(self.email.text())
        password = str(self.password.text())
        rePassword = str(self.rePassword.text())
        
        #Insert logic starts here
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        #add decryptor here
        if (fname != "" and lname != "" and employeeId != "" and email != "" and password != "" and rePassword):
            if len(password) >= 8:
                if(password == rePassword):         
                    ready.execute("INSERT INTO employees (employeeID, first_name, last_name, email, password) VALUES (%s, %s, %s, %s, %s)", (employeeId, fname, lname, email, password))
                    mydb.commit()
                else:
                    #unmatched
                    print("\n\nPassword must match")
            else:
                #Kulang sa characters yung password
                print("\n\nPassword must be atleast 8 characters long")
        else:
            print("\n\nFill Up all boxes")



#Movie Information GLOBAL VARIBLE (FOR SESSION)         
cinema_room = ""
movie_name = ""
genre = ""
duration = ""
mtrbc_rating = ""
      
                      
#DASHBOARD SCREEN
class DashboardScreen(QtWidgets.QWidget):
    #LOCAL VARIABLE
    session_employeeID=""
    session_fName=""
    session_lName=""
    session_email=""
    session_password=""
        
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/dashboard.ui", self)
        self.stacked_widget = stacked_widget
        
        self.home_screen = HomeScreen(self.stacked_widget)
        self.movies_screen = MoviesScreen(self.stacked_widget)
        self.movie_logs = MovieLogsScreen(self.stacked_widget)
        self.seats_screen = SeatsScreen(self.stacked_widget)
        
        self.stackedWidget.addWidget(self.home_screen)
        self.stackedWidget.addWidget(self.movies_screen)
        self.stackedWidget.addWidget(self.movie_logs)
        self.stackedWidget.addWidget(self.seats_screen)
        
        # connect sidebar buttons
        self.homeBtn.clicked.connect(self.show_home)
        self.moviesBtn.clicked.connect(self.show_movies)
        self.movieLogsBtn.clicked.connect(self.show_movie_logs)
        
        
        #Gawa ng difference dito (Dapat mag s-set sya ng certain cinema-info based sa movie na cli-nick)
        
        self.movies_screen.cinema1.clicked.connect(partial(self.show_seats, "Cinema 1")) 
        self.movies_screen.cinema2.clicked.connect(partial(self.show_seats, "Cinema 2"))  
        self.movies_screen.cinema3.clicked.connect(partial(self.show_seats, "Cinema 3"))  
        self.movies_screen.cinema4.clicked.connect(partial(self.show_seats, "Cinema 4"))
        
        self.show_home()
        
        
    def show_home(self):
        self.stackedWidget.setCurrentWidget(self.home_screen)
        
    def show_movies(self):
        self.stackedWidget.setCurrentWidget(self.movies_screen)
        
    def show_movie_logs(self):
        self.stackedWidget.setCurrentWidget(self.movie_logs)
        
        
    #Loading seats screen
    def show_seats(self, cinema_set):
        
        #Movie session LOGIC
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT cinema_room, movie_name, genre, duration, mtrbc_rating FROM movies WHERE cinema_room = %s", (cinema_set,))
        result = ready.fetchall()
        
        for i in result:
            #Pang change ng value ng mga global Variable
            global cinema_room
            global movie_name
            global  genre
            global duration
            global  mtrbc_rating
                                                    
            cinema_room = i[0]
            movie_name = i[1]
            genre = i[2]
            duration = i[3]
            mtrbc_rating = i[4]
        
        
        #Go to the seat
        self.seats_screen.load_latests()
        self.seats_screen.seatViewer()  
        self.stackedWidget.setCurrentWidget(self.seats_screen)
         
        
            
    def load_latest(self):
        
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_employeeID= session_employeeID
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.session_email= session_email
        self.session_password= session_password
            
        self.firstName.setText("First Name:"+self.session_fName)
        self.lastName.setText("Last Name: "+self.session_lName)
        self.employeeID.setText("Employee ID: "+self.session_employeeID)
        self.email.setText("Email: "+self.session_email)
        self.password.setText("Password: "+self.session_password)




#HOME SCREEN
class HomeScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/home.ui", self) 
        self.stacked_widget = stacked_widget




# MOVIES SCREEN
class MoviesScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movies.ui", self) 
        self.stacked_widget = stacked_widget
        
        

    
    
        
#MOVIE LOGS SCREEN        
class MovieLogsScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movieLogs.ui", self) 
        self.stacked_widget = stacked_widget





#SEATS SCREEN        
class SeatsScreen(QtWidgets.QWidget):
    #Local Varibles
    cinema_room = ""
    movie_name = ""
    genre = ""
    duration = ""
    mtrbc_rating = ""
       
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/seats.ui", self)
        self.stacked_widget = stacked_widget
                
        #Pang view ng occupied seats
        self.viewSeats.clicked.connect(self.seatViewer)
        
        
        #Pang reserve ng seats na naka select
        self.reserveBtn.clicked.connect(self.reserveTickets)
        
        def show_occupant_popup(self):
            self.popup = OccupantTypeDialog()
            self.popup.exec()
        
        #Pang default 1 sa spinbox
        self.ticketCount.setValue(1)


        #List to ng mga object name ng mga button
        seat_list = ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a12", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10", "b11", "b12", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "c11", "c12", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12"]

        for seat_name in seat_list:
            #Pang re-assign ng button sa object name (Gumagawa sya ng virtual na self.a1 - self.d12)
            button = getattr(self, seat_name)
            
            #Yung partial() is pang set lang ng mga ibabato na argument sa seatClicked function and mag b-based sya sa current loop kung ano yung value ng seat_name
            button.clicked.connect(partial(self.seatClicked, seat_name))
    
    def load_latests(self):
        self.cinema_room = cinema_room
        self.movie_name = movie_name
        self.genre = genre
        self.duration = duration
        self.mtrbc_rating = mtrbc_rating
        
        self.cinema_number.setText(self.cinema_room)
        self.movieTitle.setText("Movie Title: "+self.movie_name)
    
    def seatViewer(self):
        #Pang visualiza ng occupied seats based sa movie, schedule, and date
        seat_list = ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a12", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10", "b11", "b12", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "c11", "c12", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12"]
        
        for seat_name in seat_list:
            button = getattr(self, seat_name)
            button.setStyleSheet("")
        
        date = str(self.calendar.selectedDate())
        date = date[19:-1]
        date = date.replace(",", "-")
        date = date.replace(" ", "")
    
        
        schedule = (self.time.currentText())
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT seat FROM reserved_tickets WHERE movie_name = %s AND schedule = %s AND date = %s", (self.movie_name, schedule, date))
        result = ready.fetchall()
        
        #Eto yung mga nag s-set ng mga occupied na seat based sa criteria from the database
        for i in result:                
            for seat_name in seat_list:
                button = getattr(self, seat_name)
                if(str(button.text())==i[0]):
                    button.setStyleSheet("background-color: red")
                    
        #Pang reset ng value ng selected seats kung sakali na may mag switch ng condition while may naka select
        self.selected_seat = []


    
    def reserveTickets(self):     
        #Date EX: 2025, 3, 10
        date = str(self.calendar.selectedDate())
        date = date[19:-1] #Returns only the (year, month, day) of the date from QCalendar
        
        
        #Need to para ma-compare yung date sa curdate() sakaling may mapag gamitan
        date = date.replace(",", "-")
        date = date.replace(" ", "")
                

        #Schedule EX: 10:00AM
        schedule = (self.time.currentText())
        
        if(len(self.selected_seat) == self.ticketCount.value()):
            
            self.type_dialog = OccupantTypeDialog()
            self.type_dialog.exec()
            
            for seats in self.selected_seat:
                print(seats) 
                #FOR TESTING
                print(self.movie_name+" "+schedule+" "+date+" "+seats)
                #Ticket insertion logic
                mydb = create_db_connection()
                ready = mydb.cursor()
                ready.execute("INSERT INTO reserved_tickets (movie_name, schedule, date, seat) VALUES (%s, %s, %s, %s)", (self.movie_name, schedule, date, seats))
                mydb.commit()
        else:
            print("Not total amount of selected seat")
            if(len(self.selected_seat) > self.ticketCount.value()):
                print("Sobra yung naka select na seat")
            elif(len(self.selected_seat) > self.ticketCount.value()):
                print("Kulang yung naka select na seat")
        
        self.seatViewer() #Pang instant update ng occupied space



    selected_seat = []    
    def seatClicked(self, seat):
        
        #Nagiging re-assign nung kung anong value man yung na send
        button_change = getattr(self, seat)

        #Color detection
        if (button_change.styleSheet() != "background-color: #228B22" and button_change.styleSheet() != "background-color: red" and len(self.selected_seat) < self.ticketCount.value() ):
            #Dito pupunta kapag hindi pa sya red/occupied
            
            #Change ng color
            button_change.setStyleSheet("background-color: #228B22")
            self.selected_seat.append(button_change.text())
            
    
        elif (button_change.styleSheet() == "background-color: #228B22" and button_change.styleSheet() != "background-color: red"):
            #Dito pupunta kapag red na yung color nya
            button_change.setStyleSheet("")
            for slots in self.selected_seat:
                if(slots==button_change.text()):
                    self.selected_seat.remove(button_change.text())
             

            
#POP-UP OCCUPANT TYPE
class OccupantTypeDialog(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/occupant_type.ui", self)
        
        #Dropdown Menu
        self.occupantComboBox.addItems(["Regular", "Senior", "PWD"])
        
        self.proceedBtn.clicked.connect(self.open_payment)

    def open_payment(self):
        selected_type = self.occupantComboBox.currentText()
        
        self.accept()
        
        # Open the payment dialog
        self.pay_dialog = PaymentDialog(selected_type)
        self.pay_dialog.exec()
        
        
#POP-UP PAYMENT
class PaymentDialog(QtWidgets.QDialog):
    def __init__(self, occupant_type):
        super().__init__()
        uic.loadUi("user_interface/payment.ui", self)
        
        #"Regular/Senior/PWD"
        self.occupant_type = occupant_type
        
        self.payBtn.clicked.connect(self.process_payment)
        
    def process_payment(self):
        amount = self.paymentInput.text()
        
        print("\n--- TRANSACTION SUCCESS ---")
        print(f"Occupant Type: {self.occupant_type}")
        print(f"Amount Paid: {amount}")
        
        self.accept()           
        
        

        

        
     

                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                                      
        
        
        
    

        
        

        


        




