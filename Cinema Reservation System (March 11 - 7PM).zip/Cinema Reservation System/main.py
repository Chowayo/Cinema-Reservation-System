import sys

#Back-end stuff
import mysql.connector #IMPORTANT
from functools import partial #IMPORTANT

from PyQt6 import QtWidgets 
from controller.screens import LoginScreen, RegisterScreen, DashboardScreen

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    
    widget = QtWidgets.QStackedWidget()
    
    #disable ko muna to for testing 
    #widget.setStyleSheet("background-color: #6C1D2A;")
    
    #temporary color -Michael
    widget.setStyleSheet("background-color: #A9A9A9;")
    
    widget.addWidget(LoginScreen(widget))
    widget.addWidget(RegisterScreen(widget))
    
    #Dummy code by MICHAEL also nag dag-dag din ako doon sa may port
    widget.addWidget(DashboardScreen(widget ))
    
    widget.setFixedSize(455, 455)
    widget.show()
    sys.exit(app.exec())    