import sys
from PyQt6 import QtWidgets, uic

# LOGIN SCREEN
class LoginScreen(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/login.ui", self) 
        
        #registration button
        self.registerBtn.clicked.connect(self.goto_register)

    def goto_register(self):
        widget.setCurrentIndex(1)
        
        widget.setFixedSize(580, 630)

# REGISTER SCREEN
class RegisterScreen(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        # load register
        uic.loadUi("user_interface/register.ui", self)
        
        # sign in button
        self.signInBtn.clicked.connect(self.goto_login)

    def goto_login(self):
        widget.setCurrentIndex(0)
        
        widget.setFixedSize(455, 455)

# launcher
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    
    widget = QtWidgets.QStackedWidget()
    
    login_window = LoginScreen()
    register_window = RegisterScreen()
    
    widget.addWidget(login_window)
    widget.addWidget(register_window)
    
    widget.setFixedWidth(455)
    widget.setFixedHeight(455)
    
    widget.setStyleSheet("QStackedWidget { background-color: #6C1D2A; }")
    
    
    widget.show()
    
    sys.exit(app.exec())