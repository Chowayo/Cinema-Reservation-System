import sys

#Back-end stuff
import mysql.connector
from functools import partial

from PyQt6 import QtWidgets 
from controller.screens import LoginScreen, RegisterScreen, DashboardScreen, AdminDashboard 

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    widget = QtWidgets.QStackedWidget()
    
    widget.addWidget(LoginScreen(widget))
    widget.addWidget(DashboardScreen(widget))
    widget.addWidget(AdminDashboard(widget))
    
    widget.setFixedSize(430, 530)
    widget.setWindowTitle("Movie Sphere") 
    widget.show()
    sys.exit(app.exec())