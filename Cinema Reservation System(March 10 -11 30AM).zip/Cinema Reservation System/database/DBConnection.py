import mysql.connector
from mysql.connector import Error

def create_db_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="cinema_system"
        )
        
        if connection.is_connected():
            print("Successfully connected to the database")
            return connection #Used this for return

    except Error as e:
        print(f"Error while connecting to MySQL: {e}")
        return None
