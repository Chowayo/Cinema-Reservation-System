import mysql.connector #For database import

from PyQt6 import QtWidgets, uic
from database.DBConnection import create_db_connection

#SESSION/Global Variables
session_employeeID=""
session_fName=""
session_lName=""
session_email=""
session_password=""

#LOGIN SCREEN
class LoginScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/login.ui", self) 
        self.stacked_widget = stacked_widget
        
        self.registerBtn.clicked.connect(self.goto_register)
        self.loginBtn.clicked.connect(self.loginLogic)
        
        
    def goto_register(self):
        self.stacked_widget.setCurrentIndex(1)
        self.stacked_widget.setFixedSize(580, 630)
        
            
    #TO DASHBOARD
    def goto_dashboard(self):
        self.stacked_widget.setCurrentIndex(2)
        
        #Remove size limits
        self.stacked_widget.setMinimumSize(0, 0)
        self.stacked_widget.setMaximumSize(16777215, 16777215)
        
        # full screen
        self.stacked_widget.showMaximized() 
        
        dash_screen = self.stacked_widget.widget(2) 
        dash_screen.load_latest()
        
        
    def loginLogic(self ):
            #Login Logic starts here
            employeeId = str(self.employeeID.text()) 
            password = str(self.password.text())   
            mydb = create_db_connection()
            ready = mydb.cursor()
            ready.execute("SELECT employeeID, first_name, last_name, email, password FROM employees WHERE employeeID = %s AND password = %s",(employeeId, password))
            
            #Takes the result of SELECT
            result = ready.fetchall()
            
            #add decryptor here
            if(employeeId != "" and password != ""):
                if(result!=[]):
                    print("May nag match")
                    for i in result:
                        
                        #Pang change ng value ng mga global Variable
                        global session_employeeID
                        global session_fName
                        global session_lName
                        global session_email
                        global session_password
                                                              
                        session_employeeID = i[0]
                        session_fName = i[1]
                        session_lName = i[2]
                        session_email = i[3]
                        session_password = i[4]
                    self.goto_dashboard()
                    
                else:
                    print("Walang nag match")
            else:
                print("Empty Box Detected!")
                

#REGISTER SCREEN
class RegisterScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/register.ui", self)
        self.stacked_widget = stacked_widget
        
        #To login button
        self.signInBtn.clicked.connect(self.goto_login)
        
        #Register button
        self.signUpBtn.clicked.connect(self.registerLogic)
        
        
    #For loading Register page
    def goto_login(self):
        self.stacked_widget.setCurrentIndex(0)
        self.stacked_widget.setFixedSize(455, 455)    

    def registerLogic(self):
        fname = str(self.firstName.text()) 
        lname = str(self.lastName.text()) 
        employeeId = str(self.employeeID.text()) 
        email = str(self.email.text())
        password = str(self.password.text())
        rePassword = str(self.rePassword.text())
        
        #Insert logic starts here
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        #add decryptor here
        if (fname != "" and lname != "" and employeeId != "" and email != "" and password != "" and rePassword):
            if len(password) >= 8:
                if(password == rePassword):         
                    ready.execute("INSERT INTO employees (employeeID, first_name, last_name, email, password) VALUES (%s, %s, %s, %s, %s)", (employeeId, fname, lname, email, password))
                    mydb.commit()
                else:
                    #unmatched
                    print("\n\nPassword must match")
            else:
                #Kulang sa characters yung password
                print("\n\nPassword must be atleast 8 characters long")
        else:
            print("\n\nFill Up all boxes")
            
                      
#DASHBOARD SCREEN
class DashboardScreen(QtWidgets.QWidget):
    
    #LOCAL VARIABLE
    session_employeeID=""
    session_fName=""
    session_lName=""
    session_email=""
    session_password=""
        
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/dashboard.ui", self)
        self.stacked_widget = stacked_widget
        
        self.home_screen = HomeScreen(self.stacked_widget)
        self.movies_screen = MoviesScreen(self.stacked_widget)
        self.movie_logs = MovieLogsScreen(self.stacked_widget)
        self.seats_screen = SeatsScreen(self.stacked_widget)
        
        self.stackedWidget.addWidget(self.home_screen)
        self.stackedWidget.addWidget(self.movies_screen)
        self.stackedWidget.addWidget(self.movie_logs)
        self.stackedWidget.addWidget(self.seats_screen)
        
        # connect sidebar buttons
        self.homeBtn.clicked.connect(self.show_home)
        self.moviesBtn.clicked.connect(self.show_movies)
        self.movieLogsBtn.clicked.connect(self.show_movie_logs)
        
        self.movies_screen.reserveBtn1.clicked.connect(self.show_seats)
        self.movies_screen.reserveBtn2.clicked.connect(self.show_seats)
        self.movies_screen.reserveBtn3.clicked.connect(self.show_seats)
        self.movies_screen.reserveBtn4.clicked.connect(self.show_seats)
        
        self.show_home()
        
        
    def show_home(self):
        self.stackedWidget.setCurrentWidget(self.home_screen)
        
    def show_movies(self):
        self.stackedWidget.setCurrentWidget(self.movies_screen)
        
    def show_movie_logs(self):
        self.stackedWidget.setCurrentWidget(self.movie_logs)
        
    def show_seats(self):
        self.stackedWidget.setCurrentWidget(self.seats_screen)    
        
            
    def load_latest(self):
        
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_employeeID= session_employeeID
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.session_email= session_email
        self.session_password= session_password
            
        self.firstName.setText("First Name:"+self.session_fName)
        self.lastName.setText("Last Name: "+self.session_lName)
        self.employeeID.setText("Employee ID: "+self.session_employeeID)
        self.email.setText("Email: "+self.session_email)
        self.password.setText("Password: "+self.session_password)

#HOME SCREEN
class HomeScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/home.ui", self) 
        self.stacked_widget = stacked_widget

# MOVIES SCREEN
class MoviesScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movies.ui", self) 
        self.stacked_widget = stacked_widget
        
#MOVIE LOGS SCREEN        
class MovieLogsScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movieLogs.ui", self) 
        self.stacked_widget = stacked_widget

#SEATS SCREEN        
class SeatsScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/seats.ui", self)
        self.stacked_widget = stacked_widget    
        
     

                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                                      
        
        
        
    

        
        

        


        




