import sys
import mysql.connector #IMPORTANT
from PyQt6 import QtWidgets
from controller.screens import LoginScreen, RegisterScreen, DashboardScreen

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    
    widget = QtWidgets.QStackedWidget()
    widget.setStyleSheet("background-color: #6C1D2A;")
    
    widget.addWidget(LoginScreen(widget))
    widget.addWidget(RegisterScreen(widget))
    
    #Dummy code by MICHAEL also nag dag-dag din ako doon sa may port
    widget.addWidget(DashboardScreen(widget))
    
    widget.setFixedSize(455, 455)
    widget.show()
    sys.exit(app.exec())