from PyQt6 import QtWidgets, uic

#LOGIN SCREEN
class LoginScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/login.ui", self) 
        self.stacked_widget = stacked_widget
        
        self.registerBtn.clicked.connect(self.goto_register)

    def goto_register(self):
        self.stacked_widget.setCurrentIndex(1)
        self.stacked_widget.setFixedSize(580, 630)

#REGISTER SCREEN
class RegisterScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/register.ui", self)
        self.stacked_widget = stacked_widget
        
        self.signInBtn.clicked.connect(self.goto_login)

    def goto_login(self):
        self.stacked_widget.setCurrentIndex(0)
        self.stacked_widget.setFixedSize(455, 455)