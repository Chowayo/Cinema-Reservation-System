import mysql.connector #For database import
from functools import partial

#For encryption/decryption
from cryptography.fernet import Fernet

#For date
import datetime


from PyQt6 import QtWidgets, uic
from database.DBConnection import create_db_connection

#For table
from PyQt6.QtGui import QStandardItemModel, QStandardItem

#For pictures
from PyQt6.QtGui import QPixmap

#Encrypt key
key = b'NrjM4rO9c-mlJGWxNkBzFiuXNfYoj5qkzD3fJ60qpi0='


#SESSION/Global Variables
session_employeeID=""
session_fName="dummy"
session_lName="dummy"
session_email=""

#Unusable (Kasi yung encrypted value na yung papakita nya)
session_password=""


#GLOBAL FUNCTION FOR POP UP
def show_popup(title, message, icon_type):
    msg = QtWidgets.QMessageBox()
    msg.setWindowTitle(title)
    msg.setText(message)
    msg.setIcon(icon_type)
    
    # DESIGN
    msg.setStyleSheet("""
        /* Background */
        QMessageBox {
            background-color: #FFFFFF;
        }
        
        /* Text */
        QMessageBox QLabel {
            color: #6C1D2A;
            font-size: 14px;
            font-weight: bold;
            min-height: 40px; 
        }
        
        /* OK Button */
        QMessageBox QPushButton {
            background-color: #6C1D2A;
            color: #FFFFFF;
            border-radius: 5px;
            padding: 8px 20px;
            font-size: 13px;
            font-weight: bold;
        }
        
        /* Button Hover Effect */
        QMessageBox QPushButton:hover {
            background-color: #D4AF37;
            color: #6C1D2A;
        }
    """)
    
    msg.exec()

#LOGIN SCREEN
class LoginScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/login.ui", self) 
        
        
        self.stacked_widget = stacked_widget
        
        self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Expanding)
        
        self.mode.addItems(["Employee", "Admin"])
        
        self.loginBtn.clicked.connect(self.loginLogic)
        self.forgotPassBtn.clicked.connect(self.show_reset_email)
        
        
    def goto_register(self):
        self.stacked_widget.setCurrentIndex(1)
        self.stacked_widget.setFixedSize(580, 630)
    
    def show_reset_email(self):
        self.reset_email_window = ResetPassEmailScreen()
        self.reset_email_window.exec()
        
    
        
            
    #TO REGISTER
    def goto_register(self):
        self.register_window = RegisterScreen()
        self.register_window.exec()
        
    # TO EMPLOYEE DASHBOARD
    def goto_dashboard(self):
        self.stacked_widget.setCurrentIndex(1)
        
        self.stacked_widget.setMinimumSize(0, 0)
        self.stacked_widget.setMaximumSize(16777215, 16777215)
        
        self.stacked_widget.showMaximized() 
        
        dash_screen = self.stacked_widget.widget(1)
        dash_screen.load_latest()
    
    # TO ADMIN DASHBOARD
    def goto_admin_dashboard(self):
        self.stacked_widget.setCurrentIndex(2)
        
        self.stacked_widget.setMinimumSize(0, 0)
        self.stacked_widget.setMaximumSize(16777215, 16777215)
        
        self.stacked_widget.showMaximized()
        
        admin_screens = self.stacked_widget.widget(2)
        admin_screens.load_latest()
        
        
    def loginLogic(self ):
    
        #Login Logic starts here
        employeeId = str(self.employeeID.text()) 
        password = str(self.password.text())
        
        fernet = Fernet(key)
            
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        #Admin/Employee
        inside = self.mode.currentText()
        
        
           
        
        #Dito start ng decrypt process
        
        #For different login
        if(inside=="Employee"):
            ready.execute("SELECT password FROM employees WHERE employeeID = %s",(employeeId,))
        else:
            ready.execute("SELECT password FROM admin WHERE employeeID = %s",(employeeId,))
            
        result = ready.fetchall()
        
        
        for i in result:
            encrypt_password = i[0]
            print(i[0])
            
        
            
        #If match yung inserted password and encrypted password
        if(result!=[]):
            readys = mydb.cursor()
            
            if(inside=="Employee"):
                readys.execute("SELECT employeeID, first_name, last_name, email, password FROM employees WHERE employeeID = %s ",(employeeId,))
            else:
                readys.execute("SELECT employeeID, first_name, last_name, email, password FROM admin WHERE employeeID = %s ",(employeeId,))
                
            results = ready.fetchall()
            
            mydb.close() #Pang close ng DB connection ng current class
            
            #add decryptor here
            if(employeeId != "" and password != ""):
                if(str(password)==str(fernet.decrypt(encrypt_password).decode())):
                    show_popup("Success", "Login Successful!", QtWidgets.QMessageBox.Icon.Information)
                    for i in results:
                        
                        #Pang change ng value ng mga global Variable
                        global session_employeeID
                        global session_fName
                        global session_lName
                        global session_email
                        global session_password
                                                            
                        session_employeeID = i[0]
                        session_fName = i[1]
                        session_lName = i[2]
                        session_email = i[3]
                        session_password = i[4]
                    
                    if(inside=="Employee"):
                        self.goto_dashboard()
                    else:
                        self.goto_admin_dashboard() 
                else:
                    show_popup("Error", "Password is Incorrect.", QtWidgets.QMessageBox.Icon.Warning)
            else:
                show_popup("Warning", "Please fill in all boxes!", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Error", "Incorrect Employee ID.", QtWidgets.QMessageBox.Icon.Warning)

                              

#REGISTER SCREEN
class RegisterScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/register.ui", self)
        
        self.setFixedSize(580, 630) 
        
        # Buttons
        self.signUpBtn.clicked.connect(self.registerLogic)      
          

    def registerLogic(self):
        fname = str(self.firstName.text()) 
        lname = str(self.lastName.text()) 
        employeeId = str(self.employeeID.text()) 
        email = str(self.email.text())
        password = str(self.password.text())
        rePassword = str(self.rePassword.text())
        
        #Insert logic starts here
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        checker = mydb.cursor()
        checker.execute("SELECT employeeID, email FROM employees")
        checker_result = checker.fetchall()
        
        
        employeeID_checker = True
        email_checker = True
        at_checker = False
        
        
        
        #add decryptor here
        if (fname != "" and lname != "" and employeeId != "" and email != "" and password != "" and rePassword):
            if len(password) >= 8:
                if(password == rePassword):
                    for i in checker_result:
                        if(i[0]==employeeId):
                            employeeID_checker = False
                        if(i[1]==email):
                            email_checker = False
                    if employeeID_checker:
                        if email_checker:
                            for char in email:
                                if(char=="@"):
                                    at_checker = True
                            if(at_checker):    
                                #Password Encryption
                                fernet = Fernet(key)
                                password = fernet.encrypt(password.encode())             
                                ready.execute("INSERT INTO employees (employeeID, first_name, last_name, email, password) VALUES (%s, %s, %s, %s, %s)", (employeeId, fname, lname, email, password))
                                mydb.commit()
                                mydb.close() #Pang close ng DB connection ng current class
                                
                                show_popup("Success", "Registration Successful!", QtWidgets.QMessageBox.Icon.Information)
                                
                                #ADD YUNG CLOSE DITO
                                
                            else:
                                #Kapag walang @
                                show_popup("Error", "Email Not Verified.", QtWidgets.QMessageBox.Icon.Warning) 
                        else:
                            #Kapag may naulit na employeeID
                            show_popup("Error", "Email already in use.", QtWidgets.QMessageBox.Icon.Warning)   
                    else:
                        #Kapag may naulit na employeeID
                        show_popup("Error", "Employee ID already in use.", QtWidgets.QMessageBox.Icon.Warning)     
                else:
                    #unmatched
                    show_popup("Error", "Password must match.", QtWidgets.QMessageBox.Icon.Warning) 
            else:
                #Kulang sa characters yung password
                show_popup("Error", "Password must be atleast 8 characters long.", QtWidgets.QMessageBox.Icon.Warning) 

        else:
            show_popup("Warning", "Please fill in all boxes!", QtWidgets.QMessageBox.Icon.Warning)



#Movie Information GLOBAL VARIBLE (FOR SESSION)         
cinema_room = ""
movie_name = ""
genre = ""
duration = ""
price = 0
mtrbc_rating = ""
      
                      
#DASHBOARD SCREEN
class DashboardScreen(QtWidgets.QWidget):
    #LOCAL VARIABLE
    session_employeeID=""
    session_fName=""
    session_lName=""
    session_email=""
    session_password=""
    
    def load_latest(self):
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_employeeID= session_employeeID
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.session_email= session_email
        self.session_password= session_password
            
        self.firstName.setText("First Name:"+self.session_fName)
        self.lastName.setText("Last Name: "+self.session_lName)
        self.employeeID.setText("Employee ID: "+self.session_employeeID)
        self.email.setText("Email: "+self.session_email)
        self.password.setText("Password: "+self.session_password)
        
        #Pang load ng name
        self.show_home()
                
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/dashboard.ui", self)
        self.stacked_widget = stacked_widget
        
        self.home_screen = HomeScreen(self.stacked_widget)
        self.movies_screen = MoviesScreen(self.stacked_widget)
        self.movie_logs = MovieLogsScreen(self.stacked_widget)
        self.seats_screen = SeatsScreen(self.stacked_widget)
        
        
        self.stackedWidget.addWidget(self.home_screen)
        self.stackedWidget.addWidget(self.movies_screen)
        self.stackedWidget.addWidget(self.movie_logs)
        self.stackedWidget.addWidget(self.seats_screen)
        
        
        
        # connect sidebar buttons
        self.homeBtn.clicked.connect(self.show_home)
        self.moviesBtn.clicked.connect(self.show_movies)
        self.movieLogsBtn.clicked.connect(self.show_movie_logs)
        
        
        
        
        #Gawa ng difference dito (Dapat mag s-set sya ng certain cinema-info based sa movie na cli-nick)
        self.movies_screen.cinema1.clicked.connect(partial(self.show_seats, "Cinema 1")) 
        self.movies_screen.cinema2.clicked.connect(partial(self.show_seats, "Cinema 2"))  
        self.movies_screen.cinema3.clicked.connect(partial(self.show_seats, "Cinema 3"))  
        self.movies_screen.cinema4.clicked.connect(partial(self.show_seats, "Cinema 4"))
        
        #Pang boot nung wala pang name
        self.show_home() 
        
        
        
    def show_home(self):

        
        self.home_screen.load_latest()
        self.stackedWidget.setCurrentWidget(self.home_screen)
        
        
        
    def show_movies(self):
        self.stackedWidget.setCurrentWidget(self.movies_screen)
        
    def show_movie_logs(self):
        self.stackedWidget.setCurrentWidget(self.movie_logs)
        
    
        
        
    #Loading seats screen
    def show_seats(self, cinema_set):
        
        #Movie session LOGIC
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT cinema_room, movie_name, genre, duration, price, mtrbc_rating FROM movies WHERE cinema_room = %s", (cinema_set,))
        result = ready.fetchall()
        mydb.close() #Pang close ng DB connection ng current class   
        
        for i in result:
            #Pang change ng value ng mga global Variable
            global cinema_room
            global movie_name
            global  genre
            global duration
            global price
            global  mtrbc_rating
                                                    
            cinema_room = i[0]
            movie_name = i[1]
            genre = i[2]
            duration = i[3]
            price = i[4]
            mtrbc_rating = i[5]
        
        
        #Go to the seat
        self.seats_screen.load_latests()
        self.seats_screen.seatViewer()  
        self.stackedWidget.setCurrentWidget(self.seats_screen)
         
        
            





#HOME SCREEN
class HomeScreen(QtWidgets.QWidget):
    session_fName=""
    session_lName=""
    
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/home.ui", self) 
        self.stacked_widget = stacked_widget
        
        self.initials.clicked.connect(self.show_profile)
                   
        mydb = create_db_connection()
        
        
        #Tickets sold today
        tickets= mydb.cursor()
        tickets.execute("SELECT COUNT(*) FROM reserved_tickets WHERE date = CURDATE()")
        tickets_result = tickets.fetchall()
        for i in tickets_result: self.allTickets.setText(str(i[0]))
        
        #Revenue for today  
        profit = mydb.cursor()
        profit.execute("SELECT SUM(price) FROM movies INNER JOIN reserved_tickets ON movies.movie_name = reserved_tickets.movie_name and reserved_tickets.date = CURDATE()")
        profit_result = profit.fetchall()
        print(str(profit_result))
        for i in profit_result:
            if(str(profit_result) != "[(None,)]" ): 
                self.totalProfit.setText(str(i[0])+".00")
            else:
                self.totalProfit.setText("0.00")
        

        
        #Total occupied seat
        
        #Cinema 1
        c1 = mydb.cursor()
        c1.execute("SELECT COUNT(*) FROM reserved_tickets WHERE movie_name = 'Materialists' AND reserved_tickets.date = CURDATE()")
        c1_result = c1.fetchall()
        for i in c1_result: 
            self.cinema1.setText("CINEMA 1: "+str(i[0])+" TICKETS")
            count1 = int(i[0]) 
        
        #Cinema 2
        c2 = mydb.cursor()
        c2.execute("SELECT COUNT(*) FROM reserved_tickets WHERE movie_name = 'Love Me, Love Me' AND reserved_tickets.date = CURDATE()")
        c2_result = c2.fetchall()
        for i in c2_result: 
            self.cinema2.setText("CINEMA 2: "+str(i[0])+" TICKETS")
            count2 = int(i[0]) 
        
        #Cinema 3
        c3 = mydb.cursor()
        c3.execute("SELECT COUNT(*) FROM reserved_tickets WHERE movie_name = 'Hoppers' AND reserved_tickets.date = CURDATE()")
        c3_result = c3.fetchall()
        for i in c3_result: 
            self.cinema3.setText("CINEMA 3: "+str(i[0])+" TICKETS")
            count3 = int(i[0]) 
        
        #Cinema 4
        c4 = mydb.cursor()
        c4.execute("SELECT COUNT(*) FROM reserved_tickets WHERE movie_name = 'Scream 7' AND reserved_tickets.date = CURDATE()")
        c4_result = c4.fetchall()
        for i in c4_result: 
            self.cinema4.setText("CINEMA 4: "+str(i[0])+" TICKETS")
            count4 = int(i[0])
        mydb.close() #Pang close ng DB connection ng current class    
            
        #Top movie today
        counts = [count1, count2, count3, count4]
        highest = count1
        for i in counts:
            if(int(highest) > int(i)):
                print("Highest: "+str(highest))
            else:
                highest = int(i)
        if(highest==int(count1)): self.highestMovie.setText("Materialists")
        elif(highest==int(count2)): self.highestMovie.setText("Love Me, Love Me")
        elif(highest==int(count3)): self.highestMovie.setText("Hoppers")
        elif(highest==int(count4)): self.highestMovie.setText("Scream 7")
        else: self.highestMovie.setText("No Current Highest")
        self.highestCount.setText(str(highest))
    
            
    def load_latest(self):
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.employeeName.setText("Welcome Back, "+ self.session_fName)
        
        #For initial
        self.initials.setText(self.session_fName[0].upper()+self.session_lName[0].upper())
        
    def show_profile(self):
        
        
        self.profile_window = ProfileScreen()
        self.profile_window.load_latest()
        self.profile_window.exec()
                
             
        
        
        


# MOVIES SCREEN
class MoviesScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movies.ui", self) 
        self.stacked_widget = stacked_widget
        



#Need to para di-mag double run yung system kasi d-delete nya lahat if ever mag refresh si user from 1 movie to another (GLOBAL VARIABLE)
locker1= True
locker2= True
locker3= True
locker4= True 

#SEATS SCREEN        
class SeatsScreen(QtWidgets.QWidget):
    #Local Varibles
    cinema_room = ""
    movie_name = ""
    genre = ""
    duration = ""
    price = 0
    mtrbc_rating = ""
    

       
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/seats.ui", self)
        self.stacked_widget = stacked_widget
                
        #Pang view ng occupied seats
        self.viewSeats.clicked.connect(self.seatViewer)
        
        
        #Pang reserve ng seats na naka select
        self.reserveBtn.clicked.connect(self.reserveTickets)
        
        
        
        
        def show_occupant_popup(self):
            self.popup = OccupantTypeDialog()
            self.popup.exec()
        
        #Pang default 1 sa spinbox
        self.ticketCount.setValue(1)
        
        


        #List to ng mga object name ng mga button
        seat_list = ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a12", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10", "b11", "b12", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "c11", "c12", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12"]

        for seat_name in seat_list:
            #Pang re-assign ng button sa object name (Gumagawa sya ng virtual na self.a1 - self.d12)
            button = getattr(self, seat_name)
            
            #Yung partial() is pang set lang ng mga ibabato na argument sa seatClicked function and mag b-based sya sa current loop kung ano yung value ng seat_name
            button.clicked.connect(partial(self.seatClicked, seat_name))
    
    def load_latests(self):
        self.cinema_room = cinema_room
        self.movie_name = movie_name
        self.genre = genre
        self.duration = duration
        self.price = price
        self.mtrbc_rating = mtrbc_rating
        
        self.cinema_number.setText(self.cinema_room)
        self.movieTitle.setText(self.movie_name)
        print(str(self.price))
        
        poster_images = {
            "Materialists": "user_interface/images/materialistsPoster.jpg", 
            "Love Me, Love Me": "user_interface/images/lovemePoster.jpg",
            "Hoppers": "user_interface/images/hoppers.jpg",
            "Scream 7": "user_interface/images/screamPoster.jpg"
        }
        
        image_path = poster_images.get(self.movie_name, "assets/default.jpg")
        
        pixmap = QPixmap(image_path)
        self.moviePosterLabel.setPixmap(pixmap)
        
        self.moviePosterLabel.setScaledContents(True)
        
        #Bawal bumili ng ticket pass sa may time ng schedule
        
        #Pang convert ng time to hour na integer
        now = datetime.datetime.now()
        now = now.time()
        now = str(now)
        now = str(now[0]+now[1])
        now = int(now)
        print(now)


        global locker1
        global locker2
        global locker3
        global locker4


        if(now >= 10 and locker1):
            self.time.removeItem(0)
            locker1 = False
            
        if(now >= 13 and locker2):
            self.time.removeItem(0)

            locker2 = False
        if(now >= 16 and locker3):
            self.time.removeItem(0)
 
            locker3 = False
        if(now >= 19 and locker4):
            self.time.removeItem(0)
            locker4 = False
            self.time.addItem("CLOSED")
        

    
    def seatViewer(self):
        #Pang visualiza ng occupied seats based sa movie, schedule, and date
        seat_list = ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a12", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10", "b11", "b12", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "c11", "c12", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12"]
        
        for seat_name in seat_list:
            button = getattr(self, seat_name)
            button.setStyleSheet("")
        
        date = str(self.calendar.selectedDate())
        date = date[19:-1]
        date = date.replace(",", "-")
        date = date.replace(" ", "")
        
        #Bawal bumili ng ticket pass sa may time ng schedule
        
    
        
        schedule = (self.time.currentText())
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT seat FROM reserved_tickets WHERE movie_name = %s AND schedule = %s AND date = %s", (self.movie_name, schedule, date))
        result = ready.fetchall()
        
        #Eto yung mga nag s-set ng mga occupied na seat based sa criteria from the database
        for i in result:                
            for seat_name in seat_list:
                button = getattr(self, seat_name)
                if(str(button.text())==i[0]):
                    button.setStyleSheet("background-color: red")
                    
        #Pang reset ng value ng selected seats kung sakali na may mag switch ng condition while may naka select
        self.selected_seat = []


    
    def reserveTickets(self):     
        #Date EX: 2025, 3, 10
        date = str(self.calendar.selectedDate())
        date = date[19:-1] #Returns only the (year, month, day) of the date from QCalendar
        
        #Need to para ma-compare yung date sa curdate() sakaling may mapag gamitan
        date = date.replace(",", "-")
        date = date.replace(" ", "")
                

        #Schedule EX: 10:00AM
        schedule = (self.time.currentText())
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        #Minimum Date Checker
        ready.execute("SELECT CASE WHEN CURDATE() <= '"+str(date)+"' THEN 'true' ELSE 'false' END AS Expired")
        result = str(ready.fetchall())
        
        #Di ko na c-convert yan since no need naman and yan na yung dapat direct value ng minimum date
        if(result=="[('true',)]"):
            print("Valid maximum days (after 3 weeks)")
            ready.execute("SELECT CASE WHEN DATE_ADD(CURDATE(), INTERVAL 21 DAY) >= '"+str(date)+"' THEN 'true' ELSE 'false' END AS Expired")
            result = str(ready.fetchall())
            mydb.close() #Pang close ng DB connection ng current class
             
            if(result=="[('true',)]"):
                print("Valid maximum days (after 3 weeks)")
                
                if(len(self.selected_seat) == self.ticketCount.value()):
            
                    self.type_dialog = OccupantTypeDialog(self.movie_name, schedule, date, self.selected_seat, self.price, self.cinema_room)
                    self.type_dialog.exec()
                else:
                    show_popup("Warning", "Not the total number of selected seats.", QtWidgets.QMessageBox.Icon.Warning)
                    if(len(self.selected_seat) > self.ticketCount.value()):
                        show_popup("Warning", "Too many seats selected", QtWidgets.QMessageBox.Icon.Warning)
                    elif(len(self.selected_seat) > self.ticketCount.value()):
                        show_popup("Warning", "The number of selected seats is not enough", QtWidgets.QMessageBox.Icon.Warning)
                
                self.seatViewer() #Pang instant update ng occupied space
            else:
                show_popup("Warning", "Invalid maximum date", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Warning", "Invalid minimum date", QtWidgets.QMessageBox.Icon.Warning)

        
        #if(result = "('true',)")
        
        print("date: "+str(date))

        
    selected_seat = []    
    def seatClicked(self, seat):
        
        #Nagiging re-assign nung kung anong value man yung na send
        button_change = getattr(self, seat)

        #Color detection
        if (button_change.styleSheet() != "background-color: #228B22" and button_change.styleSheet() != "background-color: red" and len(self.selected_seat) < self.ticketCount.value() ):
            #Dito pupunta kapag hindi pa sya red/occupied
            
            #Change ng color
            button_change.setStyleSheet("background-color: #228B22")
            self.selected_seat.append(button_change.text())
            
    
        elif (button_change.styleSheet() == "background-color: #228B22" and button_change.styleSheet() != "background-color: red"):
            #Dito pupunta kapag red na yung color nya
            button_change.setStyleSheet("")
            for slots in self.selected_seat:
                if(slots==button_change.text()):
                    self.selected_seat.remove(button_change.text())
             


            
#POP-UP OCCUPANT TYPE
class OccupantTypeDialog(QtWidgets.QDialog):
    def __init__(self, movie_name, schedule, date, seats, price, cinema_room):
        super().__init__()
        uic.loadUi("user_interface/occupant_type.ui", self)
        
        #Dropdown Menu
        self.occupantComboBox.addItems(["Regular", "Senior", "PWD"])
        
        self.proceedBtn.clicked.connect(self.open_payment)
        
        #Pang pass ng value sa may checkout
        self.schedule = schedule
        self.movie_name = movie_name
        self.date = date
        self.seats = seats
        self.price = price
        self.cinema_room = cinema_room


    def open_payment(self):
        selected_type = self.occupantComboBox.currentText()       
        self.accept()
        
        if(selected_type!="Regular"):
            self.price *= 0.8
            
        # Open the payment dialog
        self.pay_dialog = PaymentDialog(selected_type, self.movie_name, self.schedule, self.date ,self.seats, self.price, self.cinema_room)
        self.pay_dialog.exec()
        
        
  
  
        
        
#POP-UP PAYMENT
class PaymentDialog(QtWidgets.QDialog):
    def __init__(self, occupant_type, movie_name, schedule, date, seats, price, cinema_room):
        super().__init__()
        uic.loadUi("user_interface/payment.ui", self)
        
        self.payBtn.clicked.connect(self.process_payment)
        
        #"Regular/Senior/PWD"
        self.occupant_type = occupant_type
        
        self.schedule = schedule
        self.movie_name = movie_name
        self.date = date
        self.seats = seats
        self.price = price
        self.cinema_room = cinema_room
        
        self.totalAmount.setText("Amount to pay : "+str(price * len(seats)))
        
        
    def process_payment(self):

        
        try:
            amount = int(self.paymentInput.text())
            total = int(self.price * len(self.seats))
            
            if(amount >= total):
                change = amount - total
                
                #insert Ticket Logic
                mydb = create_db_connection()
                ready = mydb.cursor()
                for seat in self.seats:
                    print(seat) 
                    print(self.movie_name+" "+self.schedule+" "+self.date+" "+seat)
                
                    ready.execute("INSERT INTO reserved_tickets (movie_name, schedule, date, seat, occupant, total_price) VALUES (%s, %s, %s, %s, %s, %s)", (self.movie_name, self.schedule, self.date, seat, self.occupant_type, self.price))
                    mydb.commit()
                    
                
                # Open the receipt window
                self.receipt_window = QtWidgets.QDialog()
                uic.loadUi("user_interface/ticket_receipt.ui", self.receipt_window)
                
                #Modifying values inside receipt
                
                #Left side of receipt
                reference = mydb.cursor()
                reference.execute("SELECT MAX(id) FROM reserved_tickets")
                reference_result = reference.fetchall()
                mydb.close() #Pang close ng DB connection ng current class
                
                for ref in reference_result: self.receipt_window.refNumber.setText(str(ref[0]))
                self.receipt_window.movieTitle.setText(self.movie_name)
                self.receipt_window.cinemaNumber.setText(self.cinema_room)
                self.receipt_window.curDate.setText(str(datetime.date.today()))
                
                #Right side of receipt
                self.receipt_window.ticketPrice.setText(str(self.price))
                self.receipt_window.ticketCount.setText(str(len(self.seats)))
                self.receipt_window.occuType.setText(self.occupant_type)
                self.receipt_window.paymentAmount.setText(str(amount))
                self.receipt_window.totalPrice.setText(str(total))
                self.receipt_window.changeAmount.setText(str(change))
                if(self.occupant_type!="Regular"):
                    discount = int(self.price * 0.2)
                    self.receipt_window.discountAmount.setText(str(discount))
                else:
                    self.receipt_window.discountAmount.setText("0")
                
                #Pang close ng receipt
                self.receipt_window.print.clicked.connect(self.receipt_window.close)
                
                
                

                # Loop through the seats again
                for current_seat in self.seats:
                    # Create a blank container
                    self.ticket_stub = QtWidgets.QWidget()
                    
                    # Load ticket
                    uic.loadUi("user_interface/single_ticket.ui", self.ticket_stub)
                  
                    #Modifying values inside ticket
                    self.ticket_stub.cinemaNum.setText(self.cinema_room)   
                    self.ticket_stub.movie_title.setText(self.movie_name)
                    self.ticket_stub.date.setText(self.date)
                    self.ticket_stub.sched.setText(self.schedule)
                    self.ticket_stub.seat_position.setText(current_seat)
                    
                    
                    # Add this ticket to the bottom 
                    self.receipt_window.widget.layout().addWidget(self.ticket_stub)
                    
                # Show the print #
                self.close()
                self.receipt_window.exec()
            else:
                show_popup("Error", "Not enough Payment", QtWidgets.QMessageBox.Icon.Warning)   
                change = 0
                
        except ValueError:
            show_popup("Error", "Invalid input!", QtWidgets.QMessageBox.Icon.Warning)
            

#MOVIE TABLE LOGS
class MovieLogsScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movieLogs.ui", self) 
        self.stacked_widget = stacked_widget
        
        self.model = QStandardItemModel()
        
        #Button connection
        self.searchBtn.clicked.connect(self.search)
        
        
        # Columns
        self.model.setHorizontalHeaderLabels([
            'ID', 'Movie Name', 'Schedule', 'Date', 'Seat', 'Occupant', 'Price'
        ])
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT * FROM reserved_tickets")
        result = ready.fetchall()
        mydb.close() #Pang close ng DB connection ng current class
        row_data = ['101', 'Inception', '14:00', '2026-03-14', 'A12', 'John Doe', '12.50'] 
        
        for i in result:
            row_data = [i[0], i[1], i[2], i[3], i[4], i[5],i[6]]
            items = [QStandardItem(str(field)) for field in row_data]
            self.model.appendRow(items)

        
        self.tableLogs.setModel(self.model)
        
        header = self.tableLogs.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Stretch)
    
    def search(self):
        search_value = self.searchField.text()
        mydb = create_db_connection()
        searcher = mydb.cursor()
        
        #If empty yung search bar babalik nya lahat ng nasa list
        if(searcher != ""):
            searcher.execute("SELECT * FROM reserved_tickets WHERE movie_name LIKE '%"+search_value+"%'")
        else:
            searcher.execute("SELECT * FROM reserved_tickets")
            
        search_result = searcher.fetchall()
        mydb.close() #Pang close ng DB connection ng current class
        
        if not search_result:
            show_popup("Search error!", "No Match!", QtWidgets.QMessageBox.Icon.Warning)
        else:  
            #Nag t-tanggal ng row before insert yung galing sa search 
            self.model.removeRows(0, self.model.rowCount())
            for i in search_result:
                row_data = [i[0], i[1], i[2], i[3], i[4], i[5],i[6]]
                items = [QStandardItem(str(field)) for field in row_data]
                self.model.appendRow(items)
 
 
 
 
 
#PROFILE POP-UP            
class ProfileScreen(QtWidgets.QDialog):
    #LOCAL VARIABLE
    session_employeeID=""
    session_fName=""
    session_lName=""
    session_email=""
    session_password=""
    
    
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/profile.ui", self)
        
        self.changePassBtn.clicked.connect(self.show_change_password)
        
    def load_latest(self):
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_employeeID= session_employeeID
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.session_email= session_email
        self.session_password= session_password
            
        self.fname.setText(self.session_fName)
        self.lname.setText(self.session_lName)
        self.empID.setText(self.session_employeeID)
        self.email.setText(self.session_email)
        
    def show_change_password(self):
        self.change_pass_window = ChangePasswordScreen(self.session_employeeID)
        self.change_pass_window.exec()
 
 
        

#CHANGE PASSWORD POP-UP
class ChangePasswordScreen(QtWidgets.QDialog):
    
    
    def __init__(self, employeeId):        
        super().__init__()
        uic.loadUi("user_interface/changepassword.ui", self)
        
        #Button connection
        self.changePassBtn.clicked.connect(self.changePass)
        
        #Local variable
        self.employeeID = employeeId
        print("EmployeeID: "+self.employeeID)
        
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT password FROM employees WHERE employeeID = %s", (self.employeeID, ))
        result = ready.fetchall()
        
        #Sets current password to match
        for i in result: self.current_pass = i[0]
        
        
    def changePass(self):
        
        self.key = b'NrjM4rO9c-mlJGWxNkBzFiuXNfYoj5qkzD3fJ60qpi0='
        fernet = Fernet(self.key)
       
    
        if(self.curPass.text()!="" and self.newPass.text()!="" and self.renewPass.text()!=""):
            if(self.curPass.text()==str(fernet.decrypt(self.current_pass).decode())):
                if len(self.newPass.text()) >= 8:
                    if(self.newPass.text()==self.renewPass.text()):
                                                
                        new_pass = fernet.encrypt(self.newPass.text().encode())
                        print("New Password: "+str(new_pass))

                        mydb = create_db_connection()
                        ready = mydb.cursor()
                        ready.execute("UPDATE employees SET password = %s WHERE employeeID = %s", (new_pass,self.employeeID))
                        mydb.commit()
                        
                        show_popup("Success", "Change Password Successful!", QtWidgets.QMessageBox.Icon.Information)
                        
                        

                        
                    else:
                        show_popup("Error", "New Password Must Match With Re-enter Password!", QtWidgets.QMessageBox.Icon.Warning)
                else:
                    show_popup("Error", "New Password Must be Atleast 8 Characters!", QtWidgets.QMessageBox.Icon.Warning)  
            else:
                show_popup("Error", "Current Password Does not Match!", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Error", "Incomplete input!", QtWidgets.QMessageBox.Icon.Warning)
            
        
        
        
#RESET PASS EMAIL POP-UP
class ResetPassEmailScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/resetpass_email.ui", self)
        
        self.resetPassEmailBtn.clicked.connect(self.goto_new_password)
        
        

    def goto_new_password(self):
        self.accept() 
        
        email = self.emailBox.text()
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT password FROM employees WHERE email = %s", (email,))
        result = ready.fetchall()
        
        if(result!=[]):
            self.new_pass_window = ResetPasswordScreen(email)
            self.new_pass_window.exec()
        else:
            show_popup("Error", "No Matched Email!", QtWidgets.QMessageBox.Icon.Warning)
 
 
        

#FINAL RESET PASSWORD POP-UP
class ResetPasswordScreen(QtWidgets.QDialog):
    def __init__(self, email):
        super().__init__()
        uic.loadUi("user_interface/resetpass.ui", self)
        self.changePassBtn.clicked.connect(self.resetPass)
        self.email = email
        
    def resetPass(self):
        new_pass = self.newPass.text()
        renew_pass = self.renewPass.text()
        
        if(new_pass!="" and renew_pass!=""):
            if len(new_pass) >= 8:
                if(new_pass==renew_pass):
                    self.key = b'NrjM4rO9c-mlJGWxNkBzFiuXNfYoj5qkzD3fJ60qpi0='
                    fernet = Fernet(self.key)
                    
                    new_pass = fernet.encrypt(self.newPass.text().encode())
                    mydb = create_db_connection()
                    ready = mydb.cursor()
                    ready.execute("UPDATE employees SET password = %s WHERE email = %s", (new_pass,self.email))
                    mydb.commit()
                    
                    show_popup("Success", "Change Password Successful!", QtWidgets.QMessageBox.Icon.Information)
                    
                else:
                    show_popup("Error", "Password Must Match with Re-enter!", QtWidgets.QMessageBox.Icon.Warning)
            else:
                show_popup("Error", "Password Must be Atleast 8 Characters!", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Error", "Empty Password Box!", QtWidgets.QMessageBox.Icon.Warning)
        



# ADMIN DASHBOARD SCREEN
class AdminDashboard(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/admin_dashboard.ui", self) 
        self.stacked_widget = stacked_widget
        
        self.model = QStandardItemModel()
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT SUM(total_price) FROM reserved_tickets WHERE date = CURDATE()")
        result = ready.fetchall()
        for i in result: self.totalProfit.setText(str(i[0])+".0")
        
        count = mydb.cursor()
        count.execute("SELECT COUNT(*) FROM employees")
        employeeCount = count.fetchall()
        for i in employeeCount: self.empCount.setText(str(i[0]))
        
        self.addEmployeeBtn.clicked.connect(self.goto_add_employee)
        self.updateEmployeeBtn.clicked.connect(self.goto_update_employee)
        self.deleteEmployeeBtn.clicked.connect(self.goto_delete_employee)
        self.initials.clicked.connect(self.show_profile)
        self.changeMovieBtn.clicked.connect(self.goto_change_movie)
        
    def show_profile(self):
        self.profile_window = ProfileScreen()
        self.profile_window.load_latest()
        self.profile_window.exec()

    def goto_add_employee(self):
        self.add_emp_window = RegisterScreen()
        self.add_emp_window.exec()

    def goto_update_employee(self):
        self.update_emp_window = UpdateEmployeeScreen()
        self.update_emp_window.exec()

    def goto_delete_employee(self):
        self.delete_emp_window = DeleteEmployeeScreen()
        self.delete_emp_window.exec()
    
    def goto_change_movie(self):
        self.change_movie_window = ChangeMovieScreen()
        self.change_movie_window.exec()
        
        
    def load_latest(self):
        self.session_fName = session_fName
        self.session_lName = session_lName
        
        #EmployeeName
        self.employeeName.setText("Welcome Back, "+self.session_fName)
        
        #initials
        self.initials.setText(self.session_fName[0].upper()+self.session_lName[0].upper())
        
    # Columns
        self.model.setHorizontalHeaderLabels([
            'Employee ID', 'First Name', 'Last Name', 'Email'
        ])
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT * FROM employees")
        result = ready.fetchall()
        mydb.close() #Pang close ng DB connection ng current class
        row_data = ['12345', 'Arf', 'Meow', 'arf@gmail.com'] 
        
        for i in result:
            row_data = [i[0], i[1], i[2], i[3]]
            items = [QStandardItem(str(field)) for field in row_data]
            self.model.appendRow(items)

        
        self.employeeLogs.setModel(self.model)
        
        header = self.employeeLogs.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Stretch)

        

#DELETE EMPLOYEE ID POP-UP
class DeleteEmployeeScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/deleteEmployee.ui", self)
        
        self.proceedBtn.clicked.connect(self.confirm_deletion)
        
    def confirm_deletion(self):
        
        employeeID = self.employeeIDInput.text()
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT employeeID FROM employees WHERE employeeID = %s", (employeeID, ))
        result = ready.fetchall()
        
        if(result!=[]):
            #Create the Message Box
            confirm_msg = QtWidgets.QMessageBox()
            confirm_msg.setWindowTitle("Confirm Deletion")
            confirm_msg.setText("Are you sure you want to delete this employee?")
            confirm_msg.setIcon(QtWidgets.QMessageBox.Icon.Warning)
            
            confirm_msg.setStandardButtons(
                QtWidgets.QMessageBox.StandardButton.Yes | 
                QtWidgets.QMessageBox.StandardButton.No
            )
            
            confirm_msg.setStyleSheet("""
                QMessageBox { background-color: #FFFFFF; }
                QMessageBox QLabel { 
                    color: #6C1D2A; 
                    font-size: 14px; 
                    font-weight: bold; 
                }
                QMessageBox QPushButton {
                    background-color: #6C1D2A;
                    color: #FFFFFF;
                    border-radius: 5px;
                    padding: 8px 20px;
                    font-size: 13px;
                    font-weight: bold;
                }
                QMessageBox QPushButton:hover {
                    background-color: #D4AF37;
                    color: #6C1D2A;
                }
            """)

            result = confirm_msg.exec()

            if result == QtWidgets.QMessageBox.StandardButton.Yes:
                delete = mydb.cursor()
                delete.execute("DELETE FROM employees WHERE employeeID = %s", (employeeID,))
                mydb.commit()
                show_popup("Success", "Employee Delete Successful!", QtWidgets.QMessageBox.Icon.Information)
                
                self.close()
            else:

                self.close()
        else:
            show_popup("Error", "No EmployeeID Matched!", QtWidgets.QMessageBox.Icon.Warning)
            


#UPDATE EMPLOYEE ID POP-UP
class UpdateEmployeeScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/updateEmployee.ui", self)
        
        self.proceedBtn.clicked.connect(self.goto_update_profile_employee)
        
    def goto_update_profile_employee(self):
        self.accept()
        
        employeeID = self.employeeIDInput.text()
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT employeeID FROM employees WHERE employeeID = %s", (employeeID, ))
        result = ready.fetchall()
        
        if(result!=[]):
            self.update_emp_profile_window = UpdateEmployeeProfile(employeeID)
            self.update_emp_profile_window.exec()
        else:
            show_popup("Error", "No EmployeeID Matched!", QtWidgets.QMessageBox.Icon.Warning)
            

        
#UPDATE EMPLOYEES PROFILE POP-UP
class UpdateEmployeeProfile(QtWidgets.QDialog):
    def __init__(self, employeeID):
        super().__init__()
        uic.loadUi("user_interface/employeeProfile.ui", self)
        
        self.employeeID = employeeID
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT employeeID, first_name, last_name, email FROM employees WHERE employeeID = %s", (employeeID, ))
        result = ready.fetchall()
        
        for i in result: 
            self.employeeID = i[0]
            self.fName = i[1]
            self.lName = i[2]
            self.emails = i[3]
        
        self.fname.setText(self.fName)
        self.lname.setText(self.lName)   
        self.empID.setText(self.employeeID)   
        self.email.setText(self.emails)
        
        self.updateBtn.clicked.connect(self.updateEmployee)
        
    def updateEmployee(self):
        new_fname = self.fname.text()
        new_lname = self.lname.text()       
        new_employeeID = self.empID.text() 
        new_email = self.email.text()
        
        employeeID_checker = True
        email_checker = True
        at_checker = False
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT employeeID, email FROM employees WHERE employeeID != %s", (self.employeeID, ))
        result = ready.fetchall()
        
        #Pang check kung may naulit na email or employeeID
        for i in result:
            if(new_employeeID==i[0]):
                employeeID_checker = False
            if(new_email==i[1]):
                email_checker = False
        
        for char in new_email:
            if(char=="@"):
                at_checker = True
        
        if(new_fname!="" and new_lname !="" and new_employeeID!="" and new_email!=""):
            if(email_checker):
                if(employeeID_checker):
                    if(at_checker):
                        ready = mydb.cursor()
                        ready.execute("UPDATE employees SET employeeID = %s, first_name = %s, last_name = %s, email = %s WHERE employeeID = %s ", (new_employeeID, new_fname, new_lname, new_email, self.employeeID))
                        mydb.commit()
                        show_popup("Success", "Employee Information Updated Successful!", QtWidgets.QMessageBox.Icon.Information)   
                        self.close()
                        
                    else:
                        show_popup("Warning", "Email not Verified!", QtWidgets.QMessageBox.Icon.Warning)
                else:
                    show_popup("Warning", "EmployeeID Already In-use!", QtWidgets.QMessageBox.Icon.Warning)
            else:
                show_popup("Warning", "Email Already In-use!", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Warning", "Please fill in all boxes!", QtWidgets.QMessageBox.Icon.Warning)
            
            
#CHANGE MOVIE POP-UP
class ChangeMovieScreen(QtWidgets.QDialog): 
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/changeMovie.ui", self)
        
            
        
        
            

        

