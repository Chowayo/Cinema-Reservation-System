import mysql.connector #For database import
from functools import partial

#For encryption/decryption
from cryptography.fernet import Fernet

#For date
import datetime

#For QFileDialog
from PyQt6.QtWidgets import QFileDialog
import os

from PyQt6 import QtWidgets, QtGui, uic
from database.DBConnection import create_db_connection

#For table
from PyQt6.QtGui import QStandardItemModel, QStandardItem

#For pictures
from PyQt6.QtGui import QPixmap

#For remember me
from PyQt6.QtCore import QSettings

#Encrypt key
key = b'NrjM4rO9c-mlJGWxNkBzFiuXNfYoj5qkzD3fJ60qpi0='


#SESSION/Global Variables
session_employeeID=""
session_fName="dummy"
session_lName="dummy"
session_email=""

#Unusable (Kasi yung encrypted value na yung papakita nya)
session_password=""


#GLOBAL FUNCTION FOR POP UP
def show_popup(title, message, icon_type):
    msg = QtWidgets.QMessageBox()
    msg.setWindowTitle(title)
    msg.setText(message)
    msg.setIcon(icon_type)
    
    # DESIGN
    msg.setStyleSheet("""
        /* Background */
        QMessageBox {
            background-color: #FFFFFF;
        }
        
        /* Text */
        QMessageBox QLabel {
            color: #6C1D2A;
            font-size: 14px;
            font-weight: bold;
            min-height: 40px; 
        }
        
        /* OK Button */
        QMessageBox QPushButton {
            background-color: #6C1D2A;
            color: #FFFFFF;
            border-radius: 5px;
            padding: 8px 20px;
            font-size: 13px;
            font-weight: bold;
        }
        
        /* Button Hover Effect */
        QMessageBox QPushButton:hover {
            background-color: #D4AF37;
            color: #6C1D2A;
        }
    """)
    
    msg.exec()

#LOGIN SCREEN
class LoginScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/login.ui", self) 
        self.stacked_widget = stacked_widget
        self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Expanding)
        self.mode.addItems(["Employee", "Admin"])

        self.load_credentials()

        # Button Connections
        self.loginBtn.clicked.connect(self.loginLogic)
        self.forgotPassBtn.clicked.connect(self.show_reset_email)
        self.registerBtn.clicked.connect(self.goto_register)

    def load_credentials(self):
        self.settings = QSettings("MovieSphere", "CinemaApp")
        
        saved_id = self.settings.value("employeeID", "")
        saved_password = self.settings.value("password", "")
        remember_state = self.settings.value("remember_me", False)

        if remember_state == True or str(remember_state).lower() == 'true':
            self.employeeID.setText(str(saved_id))
            self.password.setText(str(saved_password))
            self.rememberMe.setChecked(True)
        else:
            self.employeeID.clear()
            self.password.clear()
            self.rememberMe.setChecked(False)
        
    def goto_register(self):
        self.registration_window = RegisterScreen()
        self.registration_window.exec()
    
    def show_reset_email(self):
        self.reset_email_window = ResetPassEmailScreen()
        self.reset_email_window.exec()
        
        
    # TO EMPLOYEE DASHBOARD
    def goto_dashboard(self):
        self.stacked_widget.setCurrentIndex(1)
        
        self.stacked_widget.setMinimumSize(0, 0)
        self.stacked_widget.setMaximumSize(16777215, 16777215)
        
        self.stacked_widget.showNormal()
        
        self.stacked_widget.showMaximized() 
        
        dash_screen = self.stacked_widget.widget(1)
        dash_screen.load_latest()
    
    # TO ADMIN DASHBOARD
    def goto_admin_dashboard(self):
        self.stacked_widget.setCurrentIndex(2)
        
        self.stacked_widget.setMinimumSize(0, 0)
        self.stacked_widget.setMaximumSize(16777215, 16777215)
        
        self.stacked_widget.showNormal()
        
        self.stacked_widget.showMaximized()
        
        admin_screens = self.stacked_widget.widget(2)
        admin_screens.load_latest()
        
        
    def loginLogic(self):
        #Login Logic starts here
        employeeId = str(self.employeeID.text()) 
        password = str(self.password.text())
        
        fernet = Fernet(key)
            
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        #Admin/Employee
        inside = self.mode.currentText()
        
        #For different login
        if(inside=="Employee"):
            ready.execute("SELECT password FROM employees WHERE employeeID = %s",(employeeId,))
        else:
            ready.execute("SELECT password FROM admin WHERE employeeID = %s",(employeeId,))
            
        result = ready.fetchall()
        
        for i in result:
            encrypt_password = i[0]
            print(i[0])
            
        #If match yung inserted password and encrypted password
        if(result!=[]):
            readys = mydb.cursor()
            
            if(inside=="Employee"):
                readys.execute("SELECT employeeID, first_name, last_name, email, password FROM employees WHERE employeeID = %s ",(employeeId,))
            else:
                readys.execute("SELECT employeeID, first_name, last_name, email, password FROM admin WHERE employeeID = %s ",(employeeId,))
                
            results = readys.fetchall() 
            
            mydb.close() #Pang close ng DB connection ng current class
            
            #add decryptor here
            if(employeeId != "" and password != ""):
                if(str(password)==str(fernet.decrypt(encrypt_password).decode())):
                    show_popup("Success", "Login Successful!", QtWidgets.QMessageBox.Icon.Information)
                    for i in results:
                        
                        #Pang change ng value ng mga global Variable
                        global session_employeeID, session_fName, session_lName, session_email, session_password
                                                                            
                        session_employeeID = i[0]
                        session_fName = i[1]
                        session_lName = i[2]
                        session_email = i[3]
                        session_password = i[4]

                    #REMEMBER ME SAVE LOGIC
                    if self.rememberMe.isChecked():
                        self.settings.setValue("employeeID", employeeId)
                        self.settings.setValue("password", password)
                        self.settings.setValue("remember_me", True)
                    else:
                        self.settings.remove("employeeID")
                        self.settings.remove("password")
                        self.settings.setValue("remember_me", False)
                    
                    if(inside=="Employee"):
                        self.goto_dashboard()
                    else:
                        self.goto_admin_dashboard() 
                else:
                    show_popup("Error", "Password is Incorrect.", QtWidgets.QMessageBox.Icon.Warning)
            else:
                show_popup("Warning", "Please fill in all boxes!", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Error", "Incorrect Employee ID.", QtWidgets.QMessageBox.Icon.Warning)

                              

#REGISTER SCREEN
class RegisterScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/register.ui", self)
        
        self.setFixedSize(580, 630) 
        
        
        # Buttons
        self.signUpBtn.clicked.connect(self.registerLogic)    
          

    def registerLogic(self):
        fname = str(self.firstName.text()) 
        lname = str(self.lastName.text()) 
        employeeId = str(self.employeeID.text()) 
        email = str(self.email.text())
        password = str(self.password.text())
        rePassword = str(self.rePassword.text())
        
        #Insert logic starts here
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        checker = mydb.cursor()
        checker.execute("SELECT employeeID, email FROM employees")
        checker_result = checker.fetchall()
        
        
        employeeID_checker = True
        email_checker = True
        at_checker = False
        
        
        
        #add decryptor here
        if (fname != "" and lname != "" and employeeId != "" and email != "" and password != "" and rePassword):
            if len(password) >= 8:
                if(password == rePassword):
                    for i in checker_result:
                        if(i[0]==employeeId):
                            employeeID_checker = False
                        if(i[1]==email):
                            email_checker = False
                    if employeeID_checker:
                        if email_checker:
                            for char in email:
                                if(char=="@"):
                                    at_checker = True
                            if(at_checker):    
                                #Password Encryption
                                fernet = Fernet(key)
                                password = fernet.encrypt(password.encode())             
                                ready.execute("INSERT INTO employees (employeeID, first_name, last_name, email, password) VALUES (%s, %s, %s, %s, %s)", (employeeId, fname, lname, email, password))
                                mydb.commit()
                                mydb.close() #Pang close ng DB connection ng current class
                                
                                show_popup("Success", "Registration Successful!", QtWidgets.QMessageBox.Icon.Information)
                                
                                #ADD YUNG CLOSE DITO
                                
                            else:
                                #Kapag walang @
                                show_popup("Error", "Email Not Verified.", QtWidgets.QMessageBox.Icon.Warning) 
                        else:
                            #Kapag may naulit na employeeID
                            show_popup("Error", "Email already in use.", QtWidgets.QMessageBox.Icon.Warning)   
                    else:
                        #Kapag may naulit na employeeID
                        show_popup("Error", "Employee ID already in use.", QtWidgets.QMessageBox.Icon.Warning)     
                else:
                    #unmatched
                    show_popup("Error", "Password must match.", QtWidgets.QMessageBox.Icon.Warning) 
            else:
                #Kulang sa characters yung password
                show_popup("Error", "Password must be atleast 8 characters long.", QtWidgets.QMessageBox.Icon.Warning) 

        else:
            show_popup("Warning", "Please fill in all boxes!", QtWidgets.QMessageBox.Icon.Warning)



#Movie Information GLOBAL VARIBLE (FOR SESSION)         
cinema_room = ""
movie_name = ""
genre = ""
duration = ""
price = 0
mtrbc_rating = ""
screening1 = ""
screening2 = ""
screening3 = ""
screening4 = ""
poster = ""
      
                      
#DASHBOARD SCREEN
class DashboardScreen(QtWidgets.QWidget):
    #LOCAL VARIABLE
    session_employeeID=""
    session_fName=""
    session_lName=""
    session_email=""
    session_password=""
    
    def load_latest(self):
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_employeeID= session_employeeID
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.session_email= session_email
        self.session_password= session_password
            
        self.firstName.setText("First Name:"+self.session_fName)
        self.lastName.setText("Last Name: "+self.session_lName)
        self.employeeID.setText("Employee ID: "+self.session_employeeID)
        self.email.setText("Email: "+self.session_email)
        self.password.setText("Password: "+self.session_password)
        
        #Pang load ng name
        self.show_home()
                
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/dashboard.ui", self)
        self.stacked_widget = stacked_widget
        
        self.home_screen = HomeScreen(self.stacked_widget)
        self.movies_screen = MoviesScreen(self.stacked_widget)
        self.movie_logs = MovieLogsScreen(self.stacked_widget)
        self.seats_screen = SeatsScreen(self.stacked_widget)
        
        
        self.stackedWidget.addWidget(self.home_screen)
        self.stackedWidget.addWidget(self.movies_screen)
        self.stackedWidget.addWidget(self.movie_logs)
        self.stackedWidget.addWidget(self.seats_screen)
        
        
        
        # connect sidebar buttons
        self.homeBtn.clicked.connect(self.show_home)
        self.moviesBtn.clicked.connect(self.show_movies)
        self.movieLogsBtn.clicked.connect(self.show_movie_logs)
        self.logoutBtn.clicked.connect(self.logout)
        
        
        
        
        #Gawa ng difference dito (Dapat mag s-set sya ng certain cinema-info based sa movie na cli-nick)
        self.movies_screen.cinema1.clicked.connect(partial(self.show_seats, "Cinema 1")) 
        self.movies_screen.cinema2.clicked.connect(partial(self.show_seats, "Cinema 2"))  
        self.movies_screen.cinema3.clicked.connect(partial(self.show_seats, "Cinema 3"))  
        self.movies_screen.cinema4.clicked.connect(partial(self.show_seats, "Cinema 4"))
        
        #Pang boot nung wala pang name
        self.show_home() 
        
        
        
    def show_home(self):

        
        self.home_screen.load_latest()
        self.stackedWidget.setCurrentWidget(self.home_screen)
        
        
        
    def show_movies(self):
        self.stackedWidget.setCurrentWidget(self.movies_screen)
        
    def show_movie_logs(self):
        self.stackedWidget.setCurrentWidget(self.movie_logs)
        
    def logout(self):
        # Clear the global session
        global session_employeeID, session_fName, session_lName, session_email, session_password
        session_employeeID = ""
        session_fName = ""
        session_lName = ""
        session_email = ""
        session_password = ""

        login_screen = self.stacked_widget.widget(0)
        
        login_screen.load_credentials()

        self.stacked_widget.setCurrentIndex(0)
        self.stacked_widget.showNormal() 
        self.stacked_widget.setFixedSize(430, 530)
        
    
        
        
    #Loading seats screen
    def show_seats(self, cinema_set):
        
        #Movie session LOGIC
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT cinema_room, movie_name, genre, duration, price, mtrbc_rating, screening_1, screening_2, screening_3, screening_4, poster FROM movies WHERE cinema_room = %s", (cinema_set,))
        result = ready.fetchall()
        mydb.close() #Pang close ng DB connection ng current class   
        
        for i in result:
            #Pang change ng value ng mga global Variable
            global cinema_room
            global movie_name
            global  genre
            global duration
            global price
            global  mtrbc_rating
            global screening1
            global screening2
            global screening3
            global screening4
            global poster
                                                    
            cinema_room = i[0]
            movie_name = i[1]
            genre = i[2]
            duration = i[3]
            price = i[4]
            mtrbc_rating = i[5] 
            screening1 = i[6] 
            screening2 = i[7] 
            screening3 = i[8] 
            screening4 = i[9]
            poster = i[10] 
        
        #Go to the seat
        self.seats_screen.load_latests()
        self.seats_screen.seatViewer()  
        self.stackedWidget.setCurrentWidget(self.seats_screen)
         
        
            





#HOME SCREEN
class HomeScreen(QtWidgets.QWidget):
    session_fName=""
    session_lName=""
    
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/home.ui", self) 
        self.stacked_widget = stacked_widget
        
        self.initials.clicked.connect(self.show_profile)
                   
        mydb = create_db_connection()
        
        
        #Tickets sold today
        tickets= mydb.cursor()
        tickets.execute("SELECT COUNT(*) FROM reserved_tickets WHERE date = CURDATE()")
        tickets_result = tickets.fetchall()
        for i in tickets_result: self.allTickets.setText(str(i[0]))
        
        #Revenue for today  
        profit = mydb.cursor()
        profit.execute("SELECT SUM(price) FROM movies INNER JOIN reserved_tickets ON movies.movie_name = reserved_tickets.movie_name and reserved_tickets.date = CURDATE()")
        profit_result = profit.fetchall()
        print(str(profit_result))
        for i in profit_result:
            if(str(profit_result) != "[(None,)]" ): 
                self.totalProfit.setText(str(i[0])+".00")
            else:
                self.totalProfit.setText("0.00")
        

        
        #Total occupied seat
            
        
        movieNames = []
        count_set = 0
        
        allMovies = mydb.cursor()
        allMovies.execute("SELECT movie_name FROM movies ORDER BY id ASC")
        allResult = allMovies.fetchall()
        
        for i in allResult:
            movieNames.append(str(i[0]))
            countCheck = mydb.cursor()
            countCheck.execute("SELECT COUNT(*) FROM reserved_tickets WHERE movie_name = '"+str(i[0])+"' AND date = CURDATE()")
            countResult = countCheck.fetchall()
            for o in countResult: 
                if(count_set==0): count1 = o[0]
                elif(count_set==1): count2 = o[0]
                elif(count_set==2): count3 = o[0]
                elif(count_set==3): count4 = o[0]
            count_set+=1
        
        
          
        self.cinema1.setText("Cinema 1: "+str(count1)+" Tickets")
        self.cinema2.setText("Cinema 2: "+str(count2)+" Tickets")  
        self.cinema3.setText("Cinema 3: "+str(count3)+" Tickets")
        self.cinema4.setText("Cinema 4: "+str(count4)+" Tickets")        
            
            
        #Top movie today
        
        highest = count1
        counts = [count1, count2, count3, count4]
        for i in counts:
            if(int(highest) > int(i)):
                print("Highest: "+str(highest))
            else:
                highest = int(i)
        
        if(highest==int(count1)): self.highestMovie.setText(movieNames[0])
        elif(highest==int(count2)): self.highestMovie.setText(movieNames[1])
        elif(highest==int(count3)): self.highestMovie.setText(movieNames[2])
        elif(highest==int(count4)): self.highestMovie.setText(movieNames[3])
        else: self.highestMovie.setText("No Current Highest")
        self.highestCount.setText(str(highest))
    
            
    def load_latest(self):
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.employeeName.setText("Welcome Back, "+ self.session_fName)
        
        #For initial
        self.initials.setText(self.session_fName[0].upper()+self.session_lName[0].upper())
        
    def show_profile(self):
        
        
        self.profile_window = ProfileScreen()
        self.profile_window.load_latest()
        self.profile_window.exec()
                
             
        
        
        


# MOVIES SCREEN
class MoviesScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movies.ui", self) 
        self.stacked_widget = stacked_widget
        
        mydb = create_db_connection()
        posters = []
        label = []
        
        allPosters = mydb.cursor()
        allPosters.execute("SELECT poster FROM movies ORDER BY id ASC")
        allResult = allPosters.fetchall()
        for i in allResult: posters.append(i[0])
        
        allInfo = mydb.cursor()
        allInfo.execute("SELECT movie_name, genre, duration FROM movies ORDER BY id ASC")
        result = allInfo.fetchall()
        #Materialists (RomCom, 1 hour & 57 minutes)
        for i in result:
            insert =  str(i[0]+" ("+i[1]+", "+i[2]+")")
            label.append(insert)

        
        #First movie
        pixmap = QPixmap("user_interface/posters/"+posters[0])
        self.moviePoster1.setPixmap(pixmap)
        self.moviePoster1.setScaledContents(True)
        self.movieLabel1.setText(label[0])
        
        #Second movie
        pixmap = QPixmap("user_interface/posters/"+posters[1])
        self.moviePoster2.setPixmap(pixmap)
        self.moviePoster2.setScaledContents(True)
        self.movieLabel2.setText(label[1])
        
        #Third movie
        pixmap = QPixmap("user_interface/posters/"+posters[2])
        self.moviePoster3.setPixmap(pixmap)
        self.moviePoster3.setScaledContents(True)
        self.movieLabel3.setText(label[2])
        
        #Fourth movie
        pixmap = QPixmap("user_interface/posters/"+posters[3])
        self.moviePoster4.setPixmap(pixmap)
        self.moviePoster4.setScaledContents(True)
        self.movieLabel4.setText(label[3])
        
        
        
        
        

        


#SEATS SCREEN        
class SeatsScreen(QtWidgets.QWidget):
    #Local Varibles
    cinema_room = ""
    movie_name = ""
    genre = ""
    duration = ""
    price = 0
    mtrbc_rating = ""
    

       
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/seats.ui", self)
        self.stacked_widget = stacked_widget
                
        #Pang view ng occupied seats
        self.viewSeats.clicked.connect(self.seatViewer)
        
        
        #Pang reserve ng seats na naka select
        self.reserveBtn.clicked.connect(self.reserveTickets)
        

        
        
        def show_occupant_popup(self):
            self.popup = OccupantTypeDialog()
            self.popup.exec()
        
        #Pang default 1 sa spinbox
        self.ticketCount.setValue(1)
        
        


        #List to ng mga object name ng mga button
        seat_list = ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a12", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10", "b11", "b12", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "c11", "c12", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12"]

        for seat_name in seat_list:
            #Pang re-assign ng button sa object name (Gumagawa sya ng virtual na self.a1 - self.d12)
            button = getattr(self, seat_name)
            
            #Yung partial() is pang set lang ng mga ibabato na argument sa seatClicked function and mag b-based sya sa current loop kung ano yung value ng seat_name
            button.clicked.connect(partial(self.seatClicked, seat_name))
        
    
    def load_latests(self):
        self.cinema_room = cinema_room
        self.movie_name = movie_name
        self.genre = genre
        self.duration = duration
        self.price = price
        self.mtrbc_rating = mtrbc_rating
        self.screening1 = screening1
        self.screening2 = screening2
        self.screening3 = screening3
        self.screening4 = screening4
        self.poster = poster
        
        self.cinema_number.setText(self.cinema_room)
        self.movieTitle.setText(self.movie_name)
        print(str(self.price))
        
        
        image_path = str("user_interface/posters/"+self.poster)
        
        pixmap = QPixmap(image_path)
        self.moviePosterLabel.setPixmap(pixmap)
        
        self.moviePosterLabel.setScaledContents(True)
        
        #Bawal bumili ng ticket pass sa may time ng schedule
        
        #Pang convert ng time to hour na integer
        now = datetime.datetime.now()
        now = now.time()
        now = str(now)
        
        
        hour = int(str(now[0]+now[1]))
        minute = int(str(now[3]+now[4]))
        
        '''
        #OVERIDE
        hour = 0
        minute = 0
        '''
        
        print("Exact time: "+str(hour)+":"+str(minute))
        
        
        if(self.time.currentText()!=""):
            self.time.removeItem(0)
            self.time.removeItem(0)
            self.time.removeItem(0)
            self.time.removeItem(0)
        
            
        self.time.addItem(self.screening1)
        self.time.addItem(self.screening2)
        self.time.addItem(self.screening3)
        self.time.addItem(self.screening4)
        
        

        
        #For time checking
        sched1_hour = int(str(self.screening1[0]+self.screening1[1]))
        sched2_hour = int(str(self.screening2[0]+self.screening2[1]))
        sched3_hour = int(str(self.screening3[0]+self.screening3[1]))
        sched4_hour = int(str(self.screening4[0]+self.screening4[1]))
        
        #For PM and AM add 12
        if(str(self.screening1[6]+screening1[7])=="PM" and sched1_hour!=12):
            sched1_hour += 12
        if(str(self.screening2[6]+screening2[7])=="PM" and sched2_hour!=12):
            sched2_hour += 12
        if(str(self.screening3[6]+screening3[7])=="PM" and sched3_hour!=12):
            sched3_hour += 12
        if(str(self.screening4[6]+screening4[7])=="PM" and sched4_hour!=12):
            sched4_hour += 12
            
        
        #Minute
        sched1_minute = int(str(self.screening1[3]+self.screening1[4]))
        sched2_minute = int(str(self.screening2[3]+self.screening2[4]))
        sched3_minute = int(str(self.screening3[3]+self.screening3[4]))
        sched4_minute = int(str(self.screening4[3]+self.screening4[4]))
        
        #FOR TESTING
        print("Sched 1: "+str(sched1_hour)+" : "+str(sched1_minute))
        print("Sched 2: "+str(sched2_hour)+" : "+str(sched2_minute))
        print("Sched 3: "+str(sched3_hour)+" : "+str(sched3_minute))
        print("Sched 4: "+str(sched4_hour)+" : "+str(sched4_minute))
        
        if(hour >= sched1_hour):
            if(minute >= sched1_minute or hour>sched1_hour):
                remove1 = self.time.findText(self.screening1)
                if (remove1>=0):
                    self.time.removeItem(remove1)
                
        if (hour >= sched2_hour):
            if(minute >= sched2_minute or hour>sched1_hour):
                remove2 = self.time.findText(self.screening2)
                if (remove2 >= 0):
                    self.time.removeItem(remove2)
                
        if (hour >= sched3_hour):
            if(minute >= sched3_minute or hour>sched1_hour):
                remove3 = self.time.findText(self.screening3)
                if (remove3 >= 0):
                    self.time.removeItem(remove3)

        if (hour >= sched4_hour):
            if(minute >= sched4_minute or hour>sched1_hour):
                remove4 = self.time.findText(self.screening4)
                if (remove4 >= 0):
                    self.time.removeItem(remove4)
                    self.time.addItem("CLOSED")
        

        
        
        

    
    def seatViewer(self):
        #Pang visualiza ng occupied seats based sa movie, schedule, and date
        seat_list = ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a12", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10", "b11", "b12", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "c11", "c12", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12"]
        
        for seat_name in seat_list:
            button = getattr(self, seat_name)
            button.setStyleSheet("")
        
        date = str(self.calendar.selectedDate())
        date = date[19:-1]
        date = date.replace(",", "-")
        date = date.replace(" ", "")
        
        #Bawal bumili ng ticket pass sa may time ng schedule
        
    
        
        schedule = (self.time.currentText())
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT seat FROM reserved_tickets WHERE movie_name = %s AND schedule = %s AND date = %s", (self.movie_name, schedule, date))
        result = ready.fetchall()
        
        #Eto yung mga nag s-set ng mga occupied na seat based sa criteria from the database
        for i in result:                
            for seat_name in seat_list:
                button = getattr(self, seat_name)
                if(str(button.text())==i[0]):
                    button.setStyleSheet("background-color: red")
                    
        #Pang reset ng value ng selected seats kung sakali na may mag switch ng condition while may naka select
        self.selected_seat = []


    
    def reserveTickets(self):     
        #Date EX: 2025, 3, 10
        date = str(self.calendar.selectedDate())
        date = date[19:-1] #Returns only the (year, month, day) of the date from QCalendar
        
        #Need to para ma-compare yung date sa curdate() sakaling may mapag gamitan
        date = date.replace(",", "-")
        date = date.replace(" ", "")
                

        #Schedule EX: 10:00AM
        schedule = (self.time.currentText())
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        #Minimum Date Checker
        ready.execute("SELECT CASE WHEN CURDATE() <= '"+str(date)+"' THEN 'true' ELSE 'false' END AS Expired")
        result = str(ready.fetchall())
        
        #Di ko na c-convert yan since no need naman and yan na yung dapat direct value ng minimum date
        
        if(schedule!="CLOSED"):
            if(result=="[('true',)]"):
                print("Valid maximum days (after 3 weeks)")
                ready.execute("SELECT CASE WHEN DATE_ADD(CURDATE(), INTERVAL 21 DAY) >= '"+str(date)+"' THEN 'true' ELSE 'false' END AS Expired")
                result = str(ready.fetchall())
                mydb.close() #Pang close ng DB connection ng current class
                
                if(result=="[('true',)]"):
                    print("Valid maximum days (after 3 weeks)")
                    
                    if(len(self.selected_seat) == self.ticketCount.value()):
                
                        self.type_dialog = OccupantTypeDialog(self.movie_name, schedule, date, self.selected_seat, self.price, self.cinema_room)
                        self.type_dialog.exec()
                    else:
                        show_popup("Warning", "Not the total number of selected seats.", QtWidgets.QMessageBox.Icon.Warning)
                        if(len(self.selected_seat) > self.ticketCount.value()):
                            show_popup("Warning", "Too many seats selected", QtWidgets.QMessageBox.Icon.Warning)
                        elif(len(self.selected_seat) > self.ticketCount.value()):
                            show_popup("Warning", "The number of selected seats is not enough", QtWidgets.QMessageBox.Icon.Warning)
                    
                    self.seatViewer() #Pang instant update ng occupied space
                else:
                    show_popup("Warning", "Invalid maximum date", QtWidgets.QMessageBox.Icon.Warning)
            else:
                show_popup("Warning", "Invalid minimum date", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Warning", "Ticket Booth is Now Closed", QtWidgets.QMessageBox.Icon.Warning)

        
        #if(result = "('true',)")
        
        print("date: "+str(date))

        
    selected_seat = []    
    def seatClicked(self, seat):
        
        #Nagiging re-assign nung kung anong value man yung na send
        button_change = getattr(self, seat)

        #Color detection
        if (button_change.styleSheet() != "background-color: #228B22" and button_change.styleSheet() != "background-color: red" and len(self.selected_seat) < self.ticketCount.value() ):
            #Dito pupunta kapag hindi pa sya red/occupied
            
            #Change ng color
            button_change.setStyleSheet("background-color: #228B22")
            self.selected_seat.append(button_change.text())
            
    
        elif (button_change.styleSheet() == "background-color: #228B22" and button_change.styleSheet() != "background-color: red"):
            #Dito pupunta kapag red na yung color nya
            button_change.setStyleSheet("")
            for slots in self.selected_seat:
                if(slots==button_change.text()):
                    self.selected_seat.remove(button_change.text())
             


            
#POP-UP OCCUPANT TYPE
class OccupantTypeDialog(QtWidgets.QDialog):
    def __init__(self, movie_name, schedule, date, seats, price, cinema_room):
        super().__init__()
        uic.loadUi("user_interface/occupant_type.ui", self)
        
        #Dropdown Menu
        self.occupantComboBox.addItems(["Regular", "Senior", "PWD"])
        
        self.proceedBtn.clicked.connect(self.open_payment)
        
        #Pang pass ng value sa may checkout
        self.schedule = schedule
        self.movie_name = movie_name
        self.date = date
        self.seats = seats
        self.price = price
        self.cinema_room = cinema_room


    def open_payment(self):
        selected_type = self.occupantComboBox.currentText()       
        self.accept()
        
        if(selected_type!="Regular"):
            self.price *= 0.8
            
        # Open the payment dialog
        self.pay_dialog = PaymentDialog(selected_type, self.movie_name, self.schedule, self.date ,self.seats, self.price, self.cinema_room)
        self.pay_dialog.exec()
        
        
  
  
        
        
#POP-UP PAYMENT
class PaymentDialog(QtWidgets.QDialog):
    def __init__(self, occupant_type, movie_name, schedule, date, seats, price, cinema_room):
        super().__init__()
        uic.loadUi("user_interface/payment.ui", self)
        
        self.payBtn.clicked.connect(self.process_payment)
        
        #"Regular/Senior/PWD"
        self.occupant_type = occupant_type
        
        self.schedule = schedule
        self.movie_name = movie_name
        self.date = date
        self.seats = seats
        self.price = price
        self.cinema_room = cinema_room
        
        self.totalAmount.setText("Amount to pay : "+str(price * len(seats)))
        
        
    def process_payment(self):

        
        try:
            amount = int(self.paymentInput.text())
            total = int(self.price * len(self.seats))
            
            if(amount >= total):
                change = amount - total
                
                #insert Ticket Logic
                mydb = create_db_connection()
                ready = mydb.cursor()
                for seat in self.seats:
                    print(seat) 
                    print(self.movie_name+" "+self.schedule+" "+self.date+" "+seat)
                
                    ready.execute("INSERT INTO reserved_tickets (movie_name, cinema_room, schedule, date, seat, occupant, total_price) VALUES (%s, %s, %s, %s, %s, %s, %s)", (self.movie_name, self.cinema_room, self.schedule, self.date, seat, self.occupant_type, self.price))
                    mydb.commit()
                    
                
                # Open the receipt window
                self.receipt_window = QtWidgets.QDialog()
                uic.loadUi("user_interface/ticket_receipt.ui", self.receipt_window)
                
                #Modifying values inside receipt
                
                #Left side of receipt
                reference = mydb.cursor()
                reference.execute("SELECT MAX(id) FROM reserved_tickets")
                reference_result = reference.fetchall()
                mydb.close() #Pang close ng DB connection ng current class
                
                for ref in reference_result: self.receipt_window.refNumber.setText(str(ref[0]))
                self.receipt_window.movieTitle.setText(self.movie_name)
                self.receipt_window.cinemaNumber.setText(self.cinema_room)
                self.receipt_window.curDate.setText(str(datetime.date.today()))
                
                #Right side of receipt
                self.receipt_window.ticketPrice.setText(str(self.price))
                self.receipt_window.ticketCount.setText(str(len(self.seats)))
                self.receipt_window.occuType.setText(self.occupant_type)
                self.receipt_window.paymentAmount.setText(str(amount))
                self.receipt_window.totalPrice.setText(str(total))
                self.receipt_window.changeAmount.setText(str(change))
                if(self.occupant_type!="Regular"):
                    discount = int(self.price * 0.2)
                    self.receipt_window.discountAmount.setText(str(discount))
                else:
                    self.receipt_window.discountAmount.setText("0")
                
                #Pang close ng receipt
                self.receipt_window.print.clicked.connect(self.receipt_window.close)
                
                
                

                # Loop through the seats again
                for current_seat in self.seats:
                    # Create a blank container
                    self.ticket_stub = QtWidgets.QWidget()
                    
                    # Load ticket
                    uic.loadUi("user_interface/single_ticket.ui", self.ticket_stub)
                  
                    #Modifying values inside ticket
                    self.ticket_stub.cinemaNum.setText(self.cinema_room)   
                    self.ticket_stub.movie_title.setText(self.movie_name)
                    self.ticket_stub.date.setText(self.date)
                    self.ticket_stub.sched.setText(self.schedule)
                    self.ticket_stub.seat_position.setText(current_seat)
                    
                    
                    # Add this ticket to the bottom 
                    self.receipt_window.widget.layout().addWidget(self.ticket_stub)
                    
                # Show the print #
                self.close()
                self.receipt_window.exec()
            else:
                show_popup("Error", "Not enough Payment", QtWidgets.QMessageBox.Icon.Warning)   
                change = 0
                
        except ValueError:
            show_popup("Error", "Invalid input!", QtWidgets.QMessageBox.Icon.Warning)
            

#MOVIE TABLE LOGS
class MovieLogsScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movieLogs.ui", self) 
        self.stacked_widget = stacked_widget
        
        self.model = QStandardItemModel()
        
        #Button connection
        self.searchBtn.clicked.connect(self.search)
        
        
        # Columns
        self.model.setHorizontalHeaderLabels([
            'Movie Name', 'Cinema Room', 'Schedule', 'Date', 'Seat', 'Occupant', 'Price', 'Cashier'
        ])
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT * FROM reserved_tickets")
        result = ready.fetchall()
        mydb.close() #Pang close ng DB connection ng current class
        row_data = ['101', 'Inception', '14:00', '2026-03-14', 'A12', 'John Doe', '12.50','John Doe'] 
        
        for i in result:
            row_data = [i[1], i[2], i[3], i[4], i[5],i[6], i[7]]
            items = [QStandardItem(str(field)) for field in row_data]
            self.model.appendRow(items)

        
        self.tableLogs.setModel(self.model)
        
        header = self.tableLogs.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Stretch)
    
    def search(self):
        search_value = self.searchField.text()
        mydb = create_db_connection()
        searcher = mydb.cursor()
        
        #If empty yung search bar babalik nya lahat ng nasa list
        if(searcher != ""):
            searcher.execute("SELECT * FROM reserved_tickets WHERE movie_name LIKE '%"+search_value+"%'")
        else:
            searcher.execute("SELECT * FROM reserved_tickets")
            
        search_result = searcher.fetchall()
        mydb.close() #Pang close ng DB connection ng current class
        
        if not search_result:
            show_popup("Search error!", "No Match!", QtWidgets.QMessageBox.Icon.Warning)
        else:  
            #Nag t-tanggal ng row before insert yung galing sa search 
            self.model.removeRows(0, self.model.rowCount())
            for i in search_result:
                row_data = [i[0], i[1], i[2], i[3], i[4], i[5],i[6]]
                items = [QStandardItem(str(field)) for field in row_data]
                self.model.appendRow(items)
 
 
 
 
 
#PROFILE POP-UP            
class ProfileScreen(QtWidgets.QDialog):
    #LOCAL VARIABLE
    session_employeeID=""
    session_fName=""
    session_lName=""
    session_email=""
    session_password=""
    
    
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/profile.ui", self)
        
        self.changePassBtn.clicked.connect(self.show_change_password)
        
    def load_latest(self):
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_employeeID= session_employeeID
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.session_email= session_email
        self.session_password= session_password
            
        self.fname.setText(self.session_fName)
        self.lname.setText(self.session_lName)
        self.empID.setText(self.session_employeeID)
        self.email.setText(self.session_email)
        
    def show_change_password(self):
        self.change_pass_window = ChangePasswordScreen(self.session_employeeID)
        self.change_pass_window.exec()
 
 
        

#CHANGE PASSWORD POP-UP
class ChangePasswordScreen(QtWidgets.QDialog):
    
    
    def __init__(self, employeeId):        
        super().__init__()
        uic.loadUi("user_interface/changepassword.ui", self)
        
        #Button connection
        self.changePassBtn.clicked.connect(self.changePass)
        
        #Local variable
        self.employeeID = employeeId
        print("EmployeeID: "+self.employeeID)
        
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT password FROM employees WHERE employeeID = %s", (self.employeeID, ))
        result = ready.fetchall()
        
        #Sets current password to match
        for i in result: self.current_pass = i[0]
        
        
    def changePass(self):
        
        self.key = b'NrjM4rO9c-mlJGWxNkBzFiuXNfYoj5qkzD3fJ60qpi0='
        fernet = Fernet(self.key)
       
    
        if(self.curPass.text()!="" and self.newPass.text()!="" and self.renewPass.text()!=""):
            if(self.curPass.text()==str(fernet.decrypt(self.current_pass).decode())):
                if len(self.newPass.text()) >= 8:
                    if(self.newPass.text()==self.renewPass.text()):
                                                
                        new_pass = fernet.encrypt(self.newPass.text().encode())
                        print("New Password: "+str(new_pass))

                        mydb = create_db_connection()
                        ready = mydb.cursor()
                        ready.execute("UPDATE employees SET password = %s WHERE employeeID = %s", (new_pass,self.employeeID))
                        mydb.commit()
                        
                        show_popup("Success", "Change Password Successful!", QtWidgets.QMessageBox.Icon.Information)
                        
                        

                        
                    else:
                        show_popup("Error", "New Password Must Match With Re-enter Password!", QtWidgets.QMessageBox.Icon.Warning)
                else:
                    show_popup("Error", "New Password Must be Atleast 8 Characters!", QtWidgets.QMessageBox.Icon.Warning)  
            else:
                show_popup("Error", "Current Password Does not Match!", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Error", "Incomplete input!", QtWidgets.QMessageBox.Icon.Warning)
            
        
        
        
#RESET PASS EMAIL POP-UP
class ResetPassEmailScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/resetpass_email.ui", self)
        
        self.resetPassEmailBtn.clicked.connect(self.goto_new_password)
        
        

    def goto_new_password(self):
        self.accept() 
        
        email = self.emailBox.text()
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT password FROM employees WHERE email = %s", (email,))
        result = ready.fetchall()
        
        if(result!=None):
            self.new_pass_window = ResetPasswordScreen(email)
            self.new_pass_window.exec()
        else:
            show_popup("Error", "No Matched Email!", QtWidgets.QMessageBox.Icon.Warning)
 
 
        

#FINAL RESET PASSWORD POP-UP
class ResetPasswordScreen(QtWidgets.QDialog):
    def __init__(self, email):
        super().__init__()
        uic.loadUi("user_interface/resetpass.ui", self)
        self.changePassBtn.clicked.connect(self.resetPass)
        self.email = email
        
    def resetPass(self):
        new_pass = self.newPass.text()
        renew_pass = self.renewPass.text()
        
        if(new_pass!="" and renew_pass!=""):
            if len(new_pass) >= 8:
                if(new_pass==renew_pass):
                    self.key = b'NrjM4rO9c-mlJGWxNkBzFiuXNfYoj5qkzD3fJ60qpi0='
                    fernet = Fernet(self.key)
                    
                    new_pass = fernet.encrypt(self.newPass.text().encode())
                    mydb = create_db_connection()
                    ready = mydb.cursor()
                    ready.execute("UPDATE employees SET password = %s WHERE email = %s", (new_pass,self.email))
                    mydb.commit()
                    
                    show_popup("Success", "Change Password Successful!", QtWidgets.QMessageBox.Icon.Information)
                    
                else:
                    show_popup("Error", "Password Must Match with Re-enter!", QtWidgets.QMessageBox.Icon.Warning)
            else:
                show_popup("Error", "Password Must be Atleast 8 Characters!", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Error", "Empty Password Box!", QtWidgets.QMessageBox.Icon.Warning)
        



# ADMIN DASHBOARD SCREEN
class AdminDashboard(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        
        
        
        super().__init__()
        uic.loadUi("user_interface/admin_dashboard.ui", self) 
        self.stacked_widget = stacked_widget
        
        
        
        #Search Button
        self.searchBtn.clicked.connect(self.search)
        
        self.logoutBtn.clicked.connect(self.logout)
        
        #TAB WIDGET
        self.movies_screen = MoviesScreen(self.stacked_widget)
        self.movie_logs = MovieLogsScreen(self.stacked_widget)
        self.seats_screen = SeatsScreen(self.stacked_widget)

        self.movie_view_stack = QtWidgets.QStackedWidget()
        self.movie_view_stack.addWidget(self.movies_screen)
        self.movie_view_stack.addWidget(self.seats_screen)

        self.adminTabWidget.addTab(self.movie_view_stack, "Movie List")
        self.adminTabWidget.addTab(self.movie_logs, "Movie Logs")

        self.movies_screen.cinema1.clicked.connect(partial(self.admin_show_seats, "Cinema 1")) 
        self.movies_screen.cinema2.clicked.connect(partial(self.admin_show_seats, "Cinema 2"))  
        self.movies_screen.cinema3.clicked.connect(partial(self.admin_show_seats, "Cinema 3"))  
        self.movies_screen.cinema4.clicked.connect(partial(self.admin_show_seats, "Cinema 4"))
        
        self.adminTabWidget.currentChanged.connect(self.reset_movie_tab)
        
        
        self.model = QStandardItemModel()
                
        
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT SUM(total_price) FROM reserved_tickets WHERE date = CURDATE()")
        result = ready.fetchall()
        
        print("RESULT: "+str(result))
        if(str(result)!="[(None,)]"):
            for i in result: self.totalProfit.setText(str(i[0])+".0")
        else:
            self.totalProfit.setText("0.0")
        
        count = mydb.cursor()
        count.execute("SELECT COUNT(*) FROM employees")
        employeeCount = count.fetchall()
        for i in employeeCount: self.empCount.setText(str(i[0]))
        
        self.addEmployeeBtn.clicked.connect(self.goto_add_employee)
        self.updateEmployeeBtn.clicked.connect(self.goto_update_employee)
        self.deleteEmployeeBtn.clicked.connect(self.goto_delete_employee)
        self.initials.clicked.connect(self.show_profile)
        self.changeMovieBtn.clicked.connect(self.goto_change_movie)
        
    def show_profile(self):
        self.profile_window = ProfileScreen()
        self.profile_window.load_latest()
        self.profile_window.exec()

    def goto_add_employee(self):
        self.add_emp_window = RegisterScreen()
        self.add_emp_window.exec()

    def goto_update_employee(self):
        self.update_emp_window = UpdateEmployeeScreen()
        self.update_emp_window.exec()

    def goto_delete_employee(self):
        self.delete_emp_window = DeleteEmployeeScreen()
        self.delete_emp_window.exec()
    
    def goto_change_movie(self):
        self.change_movie_window = ChangeMovieScreen()
        self.change_movie_window.exec()
        
    def logout(self):
        # Clear the global session
        global session_employeeID, session_fName, session_lName, session_email, session_password
        session_employeeID = ""
        session_fName = ""
        session_lName = ""
        session_email = ""
        session_password = ""

        login_screen = self.stacked_widget.widget(0)
        
        login_screen.load_credentials()

        self.stacked_widget.setCurrentIndex(0)
        self.stacked_widget.showNormal() 
        self.stacked_widget.setFixedSize(430, 530)
        
        
    def load_latest(self):
        self.session_fName = session_fName
        self.session_lName = session_lName
        
        #EmployeeName
        self.employeeName.setText("Welcome Back, "+self.session_fName)
        
        #initials
        self.initials.setText(self.session_fName[0].upper()+self.session_lName[0].upper())
        
    # Columns
        self.model.setHorizontalHeaderLabels([
            'Employee ID', 'First Name', 'Last Name', 'Email'
        ])
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT * FROM employees")
        result = ready.fetchall()
        
        row_data = ['12345', 'Arf', 'Meow', 'arf@gmail.com'] 
        
        for i in result:
            row_data = [i[1], i[2], i[3], i[4]]
            items = [QStandardItem(str(field)) for field in row_data]
            self.model.appendRow(items)

        
        self.employeeLogs.setModel(self.model)
        
        header = self.employeeLogs.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Stretch)
    
    def search(self):
        search_value = self.searchField.text()
        mydb = create_db_connection()
        searcher = mydb.cursor()
        
        #If empty yung search bar babalik nya lahat ng nasa list
        if(searcher != ""):
            searcher.execute("SELECT * FROM employees WHERE employeeID LIKE '%"+search_value+"%'")
        else:
            searcher.execute("SELECT * FROM employees")
            
        search_result = searcher.fetchall()
        mydb.close() #Pang close ng DB connection ng current class
        
        if not search_result:
            show_popup("Search error!", "No Match!", QtWidgets.QMessageBox.Icon.Warning)
        else:  
            #Nag t-tanggal ng row before insert yung galing sa search 
            self.model.removeRows(0, self.model.rowCount())
            for i in search_result:
                row_data = [i[1], i[2], i[3], i[4]]
                items = [QStandardItem(str(field)) for field in row_data]
                self.model.appendRow(items)
                
    

        
    def reset_movie_tab(self, index):
        if index == 1:
            self.movie_view_stack.setCurrentWidget(self.movies_screen)

    def admin_show_seats(self, cinema_set, checked=False):
            mydb = create_db_connection()
            ready = mydb.cursor()
            
            query = """
                SELECT cinema_room, movie_name, genre, duration, price, mtrbc_rating, 
                       screening_1, screening_2, screening_3, screening_4, poster 
                FROM movies WHERE cinema_room = %s
            """
            ready.execute(query, (cinema_set,))
            result = ready.fetchone()
            mydb.close()
            
            if result:
                global cinema_room, movie_name, genre, duration, price, mtrbc_rating, \
                       screening1, screening2, screening3, screening4, poster
                
                cinema_room = result[0]
                movie_name = result[1]
                genre = result[2]
                duration = result[3]
                price = result[4]
                mtrbc_rating = result[5]
                
                screening1 = result[6] 
                screening2 = result[7]
                screening3 = result[8]
                screening4 = result[9]
                poster = result[10] 
                
                self.seats_screen.load_latests()
                self.seats_screen.seatViewer()  
                self.movie_view_stack.setCurrentWidget(self.seats_screen)
                
    

        

#DELETE EMPLOYEE ID POP-UP
class DeleteEmployeeScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/deleteEmployee.ui", self)
        
        self.proceedBtn.clicked.connect(self.confirm_deletion)
        
    def confirm_deletion(self):
        
        employeeID = self.employeeIDInput.text()
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT employeeID FROM employees WHERE employeeID = %s", (employeeID, ))
        result = ready.fetchall()
        
        if(result!=[]):
            #Create the Message Box
            confirm_msg = QtWidgets.QMessageBox()
            confirm_msg.setWindowTitle("Confirm Deletion")
            confirm_msg.setText("Are you sure you want to delete this employee?")
            confirm_msg.setIcon(QtWidgets.QMessageBox.Icon.Warning)
            
            confirm_msg.setStandardButtons(
                QtWidgets.QMessageBox.StandardButton.Yes | 
                QtWidgets.QMessageBox.StandardButton.No
            )
            
            confirm_msg.setStyleSheet("""
                QMessageBox { background-color: #FFFFFF; }
                QMessageBox QLabel { 
                    color: #6C1D2A; 
                    font-size: 14px; 
                    font-weight: bold; 
                }
                QMessageBox QPushButton {
                    background-color: #6C1D2A;
                    color: #FFFFFF;
                    border-radius: 5px;
                    padding: 8px 20px;
                    font-size: 13px;
                    font-weight: bold;
                }
                QMessageBox QPushButton:hover {
                    background-color: #D4AF37;
                    color: #6C1D2A;
                }
            """)

            result = confirm_msg.exec()

            if result == QtWidgets.QMessageBox.StandardButton.Yes:
                delete = mydb.cursor()
                delete.execute("DELETE FROM employees WHERE employeeID = %s", (employeeID,))
                mydb.commit()
                show_popup("Success", "Employee Delete Successful!", QtWidgets.QMessageBox.Icon.Information)
                mydb.close() #Pang close ng DB connection ng current class
                self.close()
            else:

                self.close()
        else:
            show_popup("Error", "No EmployeeID Matched!", QtWidgets.QMessageBox.Icon.Warning)
            


#UPDATE EMPLOYEE ID POP-UP
class UpdateEmployeeScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/updateEmployee.ui", self)
        
        self.proceedBtn.clicked.connect(self.goto_update_profile_employee)
        
    def goto_update_profile_employee(self):
        self.accept()
        
        employeeID = self.employeeIDInput.text()
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT employeeID FROM employees WHERE employeeID = %s", (employeeID, ))
        result = ready.fetchall()
        mydb.close() #Pang close ng DB connection ng current class
        if(result!=[]):
            self.update_emp_profile_window = UpdateEmployeeProfile(employeeID)
            self.update_emp_profile_window.exec()
        else:
            show_popup("Error", "No EmployeeID Matched!", QtWidgets.QMessageBox.Icon.Warning)
            

        
#UPDATE EMPLOYEES PROFILE POP-UP
class UpdateEmployeeProfile(QtWidgets.QDialog):
    def __init__(self, employeeID):
        super().__init__()
        uic.loadUi("user_interface/employeeProfile.ui", self)
        
        self.employeeID = employeeID
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT employeeID, first_name, last_name, email FROM employees WHERE employeeID = %s", (employeeID, ))
        result = ready.fetchall()
        
        
        for i in result: 
            self.employeeID = i[0]
            self.fName = i[1]
            self.lName = i[2]
            self.emails = i[3]
        
        self.fname.setText(self.fName)
        self.lname.setText(self.lName)   
        self.empID.setText(self.employeeID)   
        self.email.setText(self.emails)
        
        self.updateBtn.clicked.connect(self.updateEmployee)
        
    def updateEmployee(self):
        new_fname = self.fname.text()
        new_lname = self.lname.text()       
        new_employeeID = self.empID.text() 
        new_email = self.email.text()
        
        employeeID_checker = True
        email_checker = True
        at_checker = False
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT employeeID, email FROM employees WHERE employeeID != %s", (self.employeeID, ))
        result = ready.fetchall()
        
        
        #Pang check kung may naulit na email or employeeID
        for i in result:
            if(new_employeeID==i[0]):
                employeeID_checker = False
            if(new_email==i[1]):
                email_checker = False
        
        for char in new_email:
            if(char=="@"):
                at_checker = True
        
        if(new_fname!="" and new_lname !="" and new_employeeID!="" and new_email!=""):
            if(email_checker):
                if(employeeID_checker):
                    if(at_checker):
                        ready = mydb.cursor()
                        ready.execute("UPDATE employees SET employeeID = %s, first_name = %s, last_name = %s, email = %s WHERE employeeID = %s ", (new_employeeID, new_fname, new_lname, new_email, self.employeeID))
                        mydb.commit()
                        mydb.close() #Pang close ng DB connection ng current class
                        show_popup("Success", "Employee Information Updated Successful!", QtWidgets.QMessageBox.Icon.Information)   
                        self.close()
                        
                    else:
                        show_popup("Warning", "Email not Verified!", QtWidgets.QMessageBox.Icon.Warning)
                else:
                    show_popup("Warning", "EmployeeID Already In-use!", QtWidgets.QMessageBox.Icon.Warning)
            else:
                show_popup("Warning", "Email Already In-use!", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Warning", "Please fill in all boxes!", QtWidgets.QMessageBox.Icon.Warning)
            
          
          
            
#CHANGE MOVIE POP-UP
class ChangeMovieScreen(QtWidgets.QDialog): 
    def __init__(self):
        super().__init__()
        uic.loadUi("user_interface/changeMovie.ui", self)
        
        #Select Photo
        self.uploadPhoto.clicked.connect(self.getFile)
        
        #Upload movie
        self.upload.clicked.connect(self.uploadMovie)
        
        self.filename = "EMPTY"
        
    def getFile(self):
        location, _ = QFileDialog.getOpenFileName(self, 'Open file', "", "All Files (*);; JPEG Files (*.jpeg);; PNG Files (*.png)")
         
        if location:
            filename = os.path.basename(location)
            
            #Local Variable
            self.filename = filename
            
            pixmap = QPixmap("user_interface/posters/"+filename)
            self.posterSample.setPixmap(pixmap)
            self.posterSample.setScaledContents(True)
        else:
            self.filename = "EMPTY"
    
    def uploadMovie(self):
        
        #Setting variables for edit
        
        cinemaRoom = self.cinemaNum.currentText()
        movieTitle = self.title.text()
        movieGenre = self.genre.currentText()
        movieDuration = self.duration.text()
        moviePrice = self.price.text()
        movieRating = self.rating.currentText()
        
        screening1 = self.screen1.text()
        screening2 = self.screen2.text()
        screening3 = self.screen3.text()
        screening4 = self.screen4.text()
        
        moviePoster = self.filename
        
        
        movie_checker = True
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT movie_name FROM movies")
        result = ready.fetchall()
        
        for i in result:
            if(str(i[0])==movieTitle):
                movie_checker = False
        
        
        if(movieTitle!="" and movieDuration!="" and moviePrice!="" and screening1!="" and screening2!="" and screening3!="" and screening4!=""):
            if(moviePoster!="EMPTY"):
                if(movie_checker):
                    ready = mydb.cursor()
                    ready.execute("UPDATE movies SET movie_name = %s, genre = %s, duration = %s, price = %s, mtrbc_rating = %s, screening_1 = %s, screening_2 = %s, screening_3 = %s, screening_4 = %s, poster = %s WHERE cinema_room = %s", (movieTitle, movieGenre, movieDuration, moviePrice, movieRating, screening1, screening2, screening3, screening4, moviePoster, cinemaRoom))
                    mydb.commit()
                    mydb.close() #Pang close ng DB connection ng current class
                    show_popup("Success", "Movie Uploaded!", QtWidgets.QMessageBox.Icon.Information)
                    self.close()
                else:
                    show_popup("Error", "Movie Already Exist!", QtWidgets.QMessageBox.Icon.Warning)
            else:
                show_popup("Error", "Please Select a Poster!", QtWidgets.QMessageBox.Icon.Warning)
        else:
            show_popup("Error", "Incomplete input!", QtWidgets.QMessageBox.Icon.Warning)