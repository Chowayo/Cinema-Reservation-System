import sys

#Back-end stuff
import mysql.connector #IMPORTANT
from functools import partial #IMPORTANT

from PyQt6 import QtWidgets 
from controller.screens import LoginScreen, RegisterScreen, DashboardScreen

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    
    widget = QtWidgets.QStackedWidget()
    
    widget.addWidget(LoginScreen(widget))
    widget.addWidget(RegisterScreen(widget))
    
    #Dummy code by MICHAEL also nag dag-dag din ako doon sa may port
    widget.addWidget(DashboardScreen(widget ))
    
    widget.setFixedSize(455, 455)
    
    widget.setWindowTitle("Movie Sphere") 
    
    widget.show()
    sys.exit(app.exec())    