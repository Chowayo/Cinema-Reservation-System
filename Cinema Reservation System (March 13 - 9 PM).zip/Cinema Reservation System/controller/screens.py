import mysql.connector #For database import
from functools import partial

#For encryption/decryption
from cryptography.fernet import Fernet

#For date
import datetime


from PyQt6 import QtWidgets, uic
from database.DBConnection import create_db_connection

#For table
from PyQt6.QtGui import QStandardItemModel, QStandardItem

#Encrypt key
key = b'NrjM4rO9c-mlJGWxNkBzFiuXNfYoj5qkzD3fJ60qpi0='


#SESSION/Global Variables
session_employeeID=""
session_fName=""
session_lName=""
session_email=""

#Unusable (Kasi yung encrypted value na yung papakita nya)
session_password=""

#LOGIN SCREEN
class LoginScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/login.ui", self) 
        
        
        self.stacked_widget = stacked_widget
        
        self.registerBtn.clicked.connect(self.goto_register)
        self.loginBtn.clicked.connect(self.loginLogic)
        
        
    def goto_register(self):
        self.stacked_widget.setCurrentIndex(1)
        self.stacked_widget.setFixedSize(580, 630)
        
            
    #TO DASHBOARD
    def goto_dashboard(self):
        self.stacked_widget.setCurrentIndex(2)
        
        #Remove size limits
        self.stacked_widget.setMinimumSize(0, 0)
        self.stacked_widget.setMaximumSize(16777215, 16777215)
        
        # full screen
        self.stacked_widget.showMaximized() 
        
        dash_screen = self.stacked_widget.widget(2) 
        dash_screen.load_latest()
        
        
    def loginLogic(self ):
            #Login Logic starts here
            employeeId = str(self.employeeID.text()) 
            password = str(self.password.text())
            
            fernet = Fernet(key)
               
            mydb = create_db_connection()
            ready = mydb.cursor()
           
           #Dito start ng decrypt process
           
            ready.execute("SELECT password FROM employees WHERE employeeID = %s",(employeeId,))
            
            #Takes the result of SELECT
            result = ready.fetchall()
            for i in result:
                encrypt_password = i[0]
                
            #If match yung inserted password and encrypted password
            if(password==str(fernet.decrypt(encrypt_password).decode())):
                readys = mydb.cursor()
                readys.execute("SELECT employeeID, first_name, last_name, email, password FROM employees WHERE employeeID = %s ",(employeeId,))
                results = ready.fetchall()
                #add decryptor here
                if(employeeId != "" and password != ""):
                    if(result!=[]):
                        print("May nag match")
                        for i in results:
                            
                            #Pang change ng value ng mga global Variable
                            global session_employeeID
                            global session_fName
                            global session_lName
                            global session_email
                            global session_password
                                                                
                            session_employeeID = i[0]
                            session_fName = i[1]
                            session_lName = i[2]
                            session_email = i[3]
                            session_password = i[4]
                        self.goto_dashboard() 
                    else:
                        print("Walang nag match")
                else:
                    print("Empty Box Detected!")
                
                
                
            else:
                print("Hindi match yung decrypt and encrypt")

           
                

#REGISTER SCREEN
class RegisterScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/register.ui", self)
        
        self.stacked_widget = stacked_widget
        
        #To login button
        self.signInBtn.clicked.connect(self.goto_login)
        
        #Register button
        self.signUpBtn.clicked.connect(self.registerLogic)      
        
    #For loading Register page
    def goto_login(self):
        self.stacked_widget.setCurrentIndex(0)
        self.stacked_widget.setFixedSize(455, 455)    

    def registerLogic(self):
        fname = str(self.firstName.text()) 
        lname = str(self.lastName.text()) 
        employeeId = str(self.employeeID.text()) 
        email = str(self.email.text())
        password = str(self.password.text())
        rePassword = str(self.rePassword.text())
        
        #Insert logic starts here
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        checker = mydb.cursor()
        checker.execute("SELECT employeeID, email FROM employees")
        checker_result = checker.fetchall()
        
        
        employeeID_checker = True
        email_checker = True
        
        
        
        #add decryptor here
        if (fname != "" and lname != "" and employeeId != "" and email != "" and password != "" and rePassword):
            if len(password) >= 8:
                if(password == rePassword):
                    for i in checker_result:
                        if(i[0]==employeeId):
                            employeeID_checker = False
                        if(i[1]==email):
                            email_checker = False
                    if employeeID_checker:
                        if email_checker:
                            #Password Encryption
                            fernet = Fernet(key)
                            password = fernet.encrypt(password.encode())             
                            ready.execute("INSERT INTO employees (employeeID, first_name, last_name, email, password) VALUES (%s, %s, %s, %s, %s)", (employeeId, fname, lname, email, password))
                            mydb.commit()
                        else:
                            #Kapag may naulit na employeeID
                            print("email already in use!")   
                    else:
                        #Kapag may naulit na employeeID
                        print("employeeID already in use!")    
                else:
                    #unmatched
                    print("\n\nPassword must match")
            else:
                #Kulang sa characters yung password
                print("\n\nPassword must be atleast 8 characters long")
        else:
            print("\n\nFill Up all boxes")



#Movie Information GLOBAL VARIBLE (FOR SESSION)         
cinema_room = ""
movie_name = ""
genre = ""
duration = ""
price = 0
mtrbc_rating = ""
      
                      
#DASHBOARD SCREEN
class DashboardScreen(QtWidgets.QWidget):
    #LOCAL VARIABLE
    session_employeeID=""
    session_fName=""
    session_lName=""
    session_email=""
    session_password=""
    
    def load_latest(self):
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_employeeID= session_employeeID
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.session_email= session_email
        self.session_password= session_password
            
        self.firstName.setText("First Name:"+self.session_fName)
        self.lastName.setText("Last Name: "+self.session_lName)
        self.employeeID.setText("Employee ID: "+self.session_employeeID)
        self.email.setText("Email: "+self.session_email)
        self.password.setText("Password: "+self.session_password)
        
        #Pang load ng name
        self.show_home()
                
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/dashboard.ui", self)
        self.stacked_widget = stacked_widget
        
        self.home_screen = HomeScreen(self.stacked_widget)
        self.movies_screen = MoviesScreen(self.stacked_widget)
        self.movie_logs = MovieLogsScreen(self.stacked_widget)
        self.seats_screen = SeatsScreen(self.stacked_widget)
        
        
        self.stackedWidget.addWidget(self.home_screen)
        self.stackedWidget.addWidget(self.movies_screen)
        self.stackedWidget.addWidget(self.movie_logs)
        self.stackedWidget.addWidget(self.seats_screen)
        
        
        
        # connect sidebar buttons
        self.homeBtn.clicked.connect(self.show_home)
        self.moviesBtn.clicked.connect(self.show_movies)
        self.movieLogsBtn.clicked.connect(self.show_movie_logs)
        
        
        
        
        #Gawa ng difference dito (Dapat mag s-set sya ng certain cinema-info based sa movie na cli-nick)
        self.movies_screen.cinema1.clicked.connect(partial(self.show_seats, "Cinema 1")) 
        self.movies_screen.cinema2.clicked.connect(partial(self.show_seats, "Cinema 2"))  
        self.movies_screen.cinema3.clicked.connect(partial(self.show_seats, "Cinema 3"))  
        self.movies_screen.cinema4.clicked.connect(partial(self.show_seats, "Cinema 4"))
        
        #Pang boot nung wala pang name
        self.show_home() 
        
        
        
    def show_home(self):

        
        self.home_screen.load_latest()
        self.stackedWidget.setCurrentWidget(self.home_screen)
        
        
        
    def show_movies(self):
        self.stackedWidget.setCurrentWidget(self.movies_screen)
        
    def show_movie_logs(self):
        self.stackedWidget.setCurrentWidget(self.movie_logs)
        
    
        
        
    #Loading seats screen
    def show_seats(self, cinema_set):
        
        #Movie session LOGIC
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT cinema_room, movie_name, genre, duration, price, mtrbc_rating FROM movies WHERE cinema_room = %s", (cinema_set,))
        result = ready.fetchall()   
        
        for i in result:
            #Pang change ng value ng mga global Variable
            global cinema_room
            global movie_name
            global  genre
            global duration
            global price
            global  mtrbc_rating
                                                    
            cinema_room = i[0]
            movie_name = i[1]
            genre = i[2]
            duration = i[3]
            price = i[4]
            mtrbc_rating = i[5]
        
        
        #Go to the seat
        self.seats_screen.load_latests()
        self.seats_screen.seatViewer()  
        self.stackedWidget.setCurrentWidget(self.seats_screen)
         
        
            





#HOME SCREEN
class HomeScreen(QtWidgets.QWidget):
    session_fName=""
    session_lName=""
    
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/home.ui", self) 
        self.stacked_widget = stacked_widget           
        mydb = create_db_connection()
        
        
        #Tickets sold today
        tickets = mydb.cursor()
        tickets.execute("SELECT COUNT(*) FROM reserved_tickets WHERE date = CURDATE()")
        tickets_result = tickets.fetchall()
        for i in tickets_result: self.allTickets.setText(str(i[0]))
        
        #Revenue for today  
        profit = mydb.cursor()
        profit.execute("SELECT SUM(price) FROM movies INNER JOIN reserved_tickets ON movies.movie_name = reserved_tickets.movie_name and reserved_tickets.date = CURDATE()")
        profit_result = profit.fetchall()
        print(str(profit_result))
        for i in profit_result:
            if(str(profit_result) != "[(None,)]" ): 
                self.totalProfit.setText(str(i[0])+".00")
            else:
                self.totalProfit.setText("0.00")
        

        
        #Total occupied seat
        
        #Cinema 1
        c1 = mydb.cursor()
        c1.execute("SELECT COUNT(*) FROM reserved_tickets WHERE movie_name = 'Materialists' AND reserved_tickets.date = CURDATE()")
        c1_result = c1.fetchall()
        for i in c1_result: 
            self.cinema1.setText("CINEMA 1: "+str(i[0])+" TICKETS")
            count1 = int(i[0]) 
        
        #Cinema 2
        c2 = mydb.cursor()
        c2.execute("SELECT COUNT(*) FROM reserved_tickets WHERE movie_name = 'Love Me, Love Me' AND reserved_tickets.date = CURDATE()")
        c2_result = c2.fetchall()
        for i in c2_result: 
            self.cinema2.setText("CINEMA 2: "+str(i[0])+" TICKETS")
            count2 = int(i[0]) 
        
        #Cinema 3
        c3 = mydb.cursor()
        c3.execute("SELECT COUNT(*) FROM reserved_tickets WHERE movie_name = 'Hoppers' AND reserved_tickets.date = CURDATE()")
        c3_result = c3.fetchall()
        for i in c3_result: 
            self.cinema3.setText("CINEMA 3: "+str(i[0])+" TICKETS")
            count3 = int(i[0]) 
        
        #Cinema 4
        c4 = mydb.cursor()
        c4.execute("SELECT COUNT(*) FROM reserved_tickets WHERE movie_name = 'Scream 7' AND reserved_tickets.date = CURDATE()")
        c4_result = c4.fetchall()
        for i in c4_result: 
            self.cinema4.setText("CINEMA 4: "+str(i[0])+" TICKETS")
            count4 = int(i[0])
            
            
        #Top movie today
        counts = [count1, count2, count3, count4]
        highest = count1
        for i in counts:
            if(int(highest) > int(i)):
                print("Highest: "+str(highest))
            else:
                highest = int(i)
        if(highest==int(count1)): self.highestMovie.setText("Materialists")
        elif(highest==int(count2)): self.highestMovie.setText("Love Me, Love Me")
        elif(highest==int(count3)): self.highestMovie.setText("Hoppers")
        elif(highest==int(count4)): self.highestMovie.setText("Scream 7")
        else: self.highestMovie.setText("No Current Highest")
        self.highestCount.setText(str(highest))
    
            
    def load_latest(self):
        #Eto na yung tatawagin para mag call ng name/etc (HINDI TO PWEDE SA INIT KASI ANG KUKUNIN NG INIT IS YUNG ORIGINAL VALUE NG GLOBAL VARIABLE)
        self.session_fName= session_fName
        self.session_lName= session_lName
        self.employeeName.setText("Welcome Back, "+ self.session_fName)
                
             
        
        
        


# MOVIES SCREEN
class MoviesScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movies.ui", self) 
        self.stacked_widget = stacked_widget
        

        
        

    
    
        
#MOVIE LOGS SCREEN        
class MovieLogsScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movieLogs.ui", self) 
        self.stacked_widget = stacked_widget





#SEATS SCREEN        
class SeatsScreen(QtWidgets.QWidget):
    #Local Varibles
    cinema_room = ""
    movie_name = ""
    genre = ""
    duration = ""
    price = 0
    mtrbc_rating = ""
       
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/seats.ui", self)
        self.stacked_widget = stacked_widget
                
        #Pang view ng occupied seats
        self.viewSeats.clicked.connect(self.seatViewer)
        
        
        #Pang reserve ng seats na naka select
        self.reserveBtn.clicked.connect(self.reserveTickets)
        
        
        def show_occupant_popup(self):
            self.popup = OccupantTypeDialog()
            self.popup.exec()
        
        #Pang default 1 sa spinbox
        self.ticketCount.setValue(1)
        
        


        #List to ng mga object name ng mga button
        seat_list = ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a12", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10", "b11", "b12", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "c11", "c12", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12"]

        for seat_name in seat_list:
            #Pang re-assign ng button sa object name (Gumagawa sya ng virtual na self.a1 - self.d12)
            button = getattr(self, seat_name)
            
            #Yung partial() is pang set lang ng mga ibabato na argument sa seatClicked function and mag b-based sya sa current loop kung ano yung value ng seat_name
            button.clicked.connect(partial(self.seatClicked, seat_name))
    
    def load_latests(self):
        self.cinema_room = cinema_room
        self.movie_name = movie_name
        self.genre = genre
        self.duration = duration
        self.price = price
        self.mtrbc_rating = mtrbc_rating
        
        self.cinema_number.setText(self.cinema_room)
        self.movieTitle.setText("Movie Title: "+self.movie_name)
        print(str(self.price))
    
    def seatViewer(self):
        #Pang visualiza ng occupied seats based sa movie, schedule, and date
        seat_list = ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10", "a11", "a12", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10", "b11", "b12", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "c11", "c12", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12"]
        
        for seat_name in seat_list:
            button = getattr(self, seat_name)
            button.setStyleSheet("")
        
        date = str(self.calendar.selectedDate())
        date = date[19:-1]
        date = date.replace(",", "-")
        date = date.replace(" ", "")
    
        
        schedule = (self.time.currentText())
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        ready.execute("SELECT seat FROM reserved_tickets WHERE movie_name = %s AND schedule = %s AND date = %s", (self.movie_name, schedule, date))
        result = ready.fetchall()
        
        #Eto yung mga nag s-set ng mga occupied na seat based sa criteria from the database
        for i in result:                
            for seat_name in seat_list:
                button = getattr(self, seat_name)
                if(str(button.text())==i[0]):
                    button.setStyleSheet("background-color: red")
                    
        #Pang reset ng value ng selected seats kung sakali na may mag switch ng condition while may naka select
        self.selected_seat = []


    
    def reserveTickets(self):     
        #Date EX: 2025, 3, 10
        date = str(self.calendar.selectedDate())
        date = date[19:-1] #Returns only the (year, month, day) of the date from QCalendar
        
        #Need to para ma-compare yung date sa curdate() sakaling may mapag gamitan
        date = date.replace(",", "-")
        date = date.replace(" ", "")
                

        #Schedule EX: 10:00AM
        schedule = (self.time.currentText())
        
        mydb = create_db_connection()
        ready = mydb.cursor()
        
        #Minimum Date Checker
        ready.execute("SELECT CASE WHEN CURDATE() <= '"+str(date)+"' THEN 'true' ELSE 'false' END AS Expired")
        result = str(ready.fetchall())
        
        #Di ko na c-convert yan since no need naman and yan na yung dapat direct value ng minimum date
        if(result=="[('true',)]"):
            print("Valid maximum days (after 3 weeks)")
            ready.execute("SELECT CASE WHEN DATE_ADD(CURDATE(), INTERVAL 21 DAY) >= '"+str(date)+"' THEN 'true' ELSE 'false' END AS Expired")
            result = str(ready.fetchall())
             
            if(result=="[('true',)]"):
                print("Valid maximum days (after 3 weeks)")
                
                if(len(self.selected_seat) == self.ticketCount.value()):
            
                    self.type_dialog = OccupantTypeDialog(self.movie_name, schedule, date, self.selected_seat, self.price, self.cinema_room)
                    self.type_dialog.exec()
                else:
                    print("Not total amount of selected seat")
                    if(len(self.selected_seat) > self.ticketCount.value()):
                        print("Sobra yung naka select na seat")
                    elif(len(self.selected_seat) > self.ticketCount.value()):
                        print("Kulang yung naka select na seat")
                
                self.seatViewer() #Pang instant update ng occupied space
            else:
                 print("Invalid maximum date")
        else:
            print("Invalid minimum date")

        
        #if(result = "('true',)")
        
        print("date: "+str(date))

        
    selected_seat = []    
    def seatClicked(self, seat):
        
        #Nagiging re-assign nung kung anong value man yung na send
        button_change = getattr(self, seat)

        #Color detection
        if (button_change.styleSheet() != "background-color: #228B22" and button_change.styleSheet() != "background-color: red" and len(self.selected_seat) < self.ticketCount.value() ):
            #Dito pupunta kapag hindi pa sya red/occupied
            
            #Change ng color
            button_change.setStyleSheet("background-color: #228B22")
            self.selected_seat.append(button_change.text())
            
    
        elif (button_change.styleSheet() == "background-color: #228B22" and button_change.styleSheet() != "background-color: red"):
            #Dito pupunta kapag red na yung color nya
            button_change.setStyleSheet("")
            for slots in self.selected_seat:
                if(slots==button_change.text()):
                    self.selected_seat.remove(button_change.text())
             


            
#POP-UP OCCUPANT TYPE
class OccupantTypeDialog(QtWidgets.QDialog):
    def __init__(self, movie_name, schedule, date, seats, price, cinema_room):
        super().__init__()
        uic.loadUi("user_interface/occupant_type.ui", self)
        
        #Dropdown Menu
        self.occupantComboBox.addItems(["Regular", "Senior", "PWD"])
        
        self.proceedBtn.clicked.connect(self.open_payment)
        
        #Pang pass ng value sa may checkout
        self.schedule = schedule
        self.movie_name = movie_name
        self.date = date
        self.seats = seats
        self.price = price
        self.cinema_room = cinema_room


    def open_payment(self):
        selected_type = self.occupantComboBox.currentText()       
        self.accept()
        
        if(selected_type!="Regular"):
            self.price *= 0.8
            
        # Open the payment dialog
        self.pay_dialog = PaymentDialog(selected_type, self.movie_name, self.schedule, self.date ,self.seats, self.price, self.cinema_room)
        self.pay_dialog.exec()
        
        
  
  
        
        
#POP-UP PAYMENT
class PaymentDialog(QtWidgets.QDialog):
    def __init__(self, occupant_type, movie_name, schedule, date, seats, price, cinema_room):
        super().__init__()
        uic.loadUi("user_interface/payment.ui", self)
        
        self.payBtn.clicked.connect(self.process_payment)
        
        #"Regular/Senior/PWD"
        self.occupant_type = occupant_type
        
        self.schedule = schedule
        self.movie_name = movie_name
        self.date = date
        self.seats = seats
        self.price = price
        self.cinema_room = cinema_room
        
        self.totalAmount.setText("Amount to pay : "+str(price * len(seats)))
        
        
    def process_payment(self):

        
        try:
            amount = int(self.paymentInput.text())
            total = int(self.price * len(self.seats))
            
            if(amount >= total):
                change = amount - total
                
                #insert Ticket Logic
                mydb = create_db_connection()
                ready = mydb.cursor()
                for seat in self.seats:
                    print(seat) 
                    print(self.movie_name+" "+self.schedule+" "+self.date+" "+seat)
                
                    ready.execute("INSERT INTO reserved_tickets (movie_name, schedule, date, seat, occupant) VALUES (%s, %s, %s, %s, %s)", (self.movie_name, self.schedule, self.date, seat, self.occupant_type))
                    mydb.commit()
                
                
                # Open the receipt window
                self.receipt_window = QtWidgets.QDialog()
                uic.loadUi("user_interface/ticket_receipt.ui", self.receipt_window)
                
                #Modifying values inside receipt
                
                #Left side of receipt
                reference = mydb.cursor()
                reference.execute("SELECT MAX(id) FROM reserved_tickets")
                reference_result = reference.fetchall()
                
                for ref in reference_result: self.receipt_window.refNumber.setText(str(ref[0]))
                self.receipt_window.movieTitle.setText(self.movie_name)
                self.receipt_window.cinemaNumber.setText(self.cinema_room)
                self.receipt_window.curDate.setText(str(datetime.date.today()))
                
                #Right side of receipt
                self.receipt_window.ticketPrice.setText(str(self.price))
                self.receipt_window.ticketCount.setText(str(len(self.seats)))
                self.receipt_window.occuType.setText(self.occupant_type)
                self.receipt_window.totalPrice.setText(str(total))
                if(self.occupant_type!="Regular"):
                    discount = int(self.price * 0.2)
                    self.receipt_window.discountAmount.setText(str(discount))
                else:
                    self.receipt_window.discountAmount.setText("0")
                
                #Pang close ng receipt
                self.receipt_window.print.clicked.connect(self.receipt_window.close)
                
                
                

                # Loop through the seats again
                for current_seat in self.seats:
                    # Create a blank container
                    self.ticket_stub = QtWidgets.QWidget()
                    
                    # Load ticket
                    uic.loadUi("user_interface/single_ticket.ui", self.ticket_stub)
                  
                    #Modifying values inside ticket
                    self.ticket_stub.cinemaNum.setText(self.cinema_room)   
                    self.ticket_stub.movie_title.setText(self.movie_name)
                    self.ticket_stub.date.setText(self.date)
                    self.ticket_stub.sched.setText(self.schedule)
                    self.ticket_stub.seat_position.setText(current_seat)
                    
                    
                    # Add this ticket to the bottom 
                    self.receipt_window.widget.layout().addWidget(self.ticket_stub)
                    
                # Show the print #
                self.close()
                self.receipt_window.exec()
            else:   
                print("\nNot enough Payment")
                change = 0
                
        except ValueError:
            print("Invalid input!")
            

#MOVIE TABLE LOGS
      
class MovieLogsScreen(QtWidgets.QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        uic.loadUi("user_interface/movieLogs.ui", self) 
        self.stacked_widget = stacked_widget
        
        self.model = QStandardItemModel()
        
        # Columns
        self.model.setHorizontalHeaderLabels([
            'ID', 'Movie Name', 'Schedule', 'Date', 'Seat', 'Occupant', 'Price'
        ])
        
        self.tableLogs.setModel(self.model)
        
        header = self.tableLogs.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Stretch)